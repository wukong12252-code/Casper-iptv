package com.casper.iptv;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

final class XtreamClient {
    private final String baseUrl;
    private final String username;
    private final String password;
    private boolean preferHls = true;
    private JSONObject userInfo = new JSONObject();

    XtreamClient(String url, String port, String username, String password) {
        this.baseUrl = normalizeBase(url, port);
        this.username = username;
        this.password = password;
    }

    static String normalizeBase(String url, String portText) {
        try {
            String value = url.trim();
            if (value.isEmpty()) throw new IllegalArgumentException();
            if (!value.contains("://")) value = "https://" + value;
            URI parsed = URI.create(value);
            String scheme = parsed.getScheme().toLowerCase(Locale.ROOT);
            if (!(scheme.equals("https") || scheme.equals("http"))
                    || parsed.getHost() == null || parsed.getRawUserInfo() != null
                    || parsed.getRawQuery() != null || parsed.getRawFragment() != null) {
                throw new IllegalArgumentException();
            }
            int port = parsed.getPort();
            if (port == 0 || port > 65535) throw new IllegalArgumentException();
            if (!portText.trim().isEmpty()) {
                int separatePort = Integer.parseInt(portText.trim());
                if (separatePort < 1 || separatePort > 65535 || (port != -1 && port != separatePort)) {
                    throw new IllegalArgumentException();
                }
                port = separatePort;
            }
            String path = parsed.getRawPath().replaceAll("/+$", "").replaceFirst("/player_api\\.php$", "");
            return scheme + "://" + parsed.getHost() + (port == -1 ? "" : ":" + port) + path;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("راجع رابط السيرفر والبورت. لو البورت موجود في الرابط، سيب خانته فاضية.");
        }
    }

    String artworkUrl(String reference) {
        if (reference.isEmpty()) return "";
        try {
            return URI.create(baseUrl + "/").resolve(reference.replace(" ", "%20")).toString();
        } catch (IllegalArgumentException invalid) {
            return "";
        }
    }

    String accountKey() {
        try {
            byte[] hash = java.security.MessageDigest.getInstance("SHA-256")
                    .digest((baseUrl + "\n" + username).getBytes(StandardCharsets.UTF_8));
            return android.util.Base64.encodeToString(hash, android.util.Base64.NO_WRAP);
        } catch (java.security.NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }

    void signIn() throws Exception {
        Object data = request(null, null, null);
        if (!(data instanceof JSONObject)) throw new IOException("رد السيرفر مش بصيغة Xtream Codes.");
        JSONObject user = ((JSONObject) data).optJSONObject("user_info");
        if (user == null || !"1".equals(user.optString("auth"))) {
            throw new IOException("السيرفر رفض الدخول. راجع اليوزر والباسورد والاشتراك.");
        }
        String status = user.optString("status");
        if (!status.isEmpty() && !"active".equalsIgnoreCase(status)) {
            throw new IOException("الاشتراك غير نشط على السيرفر.");
        }
        userInfo = user;
        JSONArray formats = user.optJSONArray("allowed_output_formats");
        if (formats != null && formats.length() > 0) {
            preferHls = false;
            for (int i = 0; i < formats.length(); i++) {
                String format = formats.optString(i);
                if ("m3u8".equalsIgnoreCase(format) || "hls".equalsIgnoreCase(format)) preferHls = true;
            }
        }
    }

    JSONObject userInfo() { return userInfo; }

    JSONArray list(String action, String category) throws Exception {
        Object data = request(action, "category_id", category);
        if (data instanceof JSONArray) return (JSONArray) data;
        if (data instanceof JSONObject && ((JSONObject) data).length() == 0) return new JSONArray();
        throw new IOException("السيرفر ما رجّعش قائمة صالحة.");
    }

    JSONObject movieInfo(String id) throws Exception {
        Object data = request("get_vod_info", "vod_id", id);
        if (data instanceof JSONObject) return (JSONObject) data;
        throw new IOException("السيرفر ما رجّعش تفاصيل الفيلم.");
    }

    JSONObject seriesInfo(String id) throws Exception {
        Object data = request("get_series_info", "series_id", id);
        if (data instanceof JSONObject) return (JSONObject) data;
        throw new IOException("السيرفر ما رجّعش تفاصيل المسلسل.");
    }

    String[] streamUrls(String kind, String id, String extension) {
        if ("live".equals(kind)) {
            String hls = stream("live", id, "m3u8");
            String ts = stream("live", id, "ts");
            return preferHls ? new String[]{hls, ts} : new String[]{ts, hls};
        }
        if (!extension.matches("[A-Za-z0-9]{1,10}")) extension = "mp4";
        return new String[]{stream(kind, id, extension)};
    }

    private String stream(String kind, String id, String extension) {
        return baseUrl + "/" + kind + "/" + encode(username) + "/" + encode(password)
                + "/" + encode(id) + "." + extension;
    }

    private Object request(String action, String argument, String value) throws Exception {
        String address = baseUrl + "/player_api.php?username=" + encode(username) + "&password=" + encode(password);
        if (action != null) address += "&action=" + encode(action);
        if (value != null) address += "&" + argument + "=" + encode(value);
        HttpURLConnection connection = (HttpURLConnection) URI.create(address).toURL().openConnection();
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(20_000);
        connection.setRequestProperty("Accept", "application/json");
        try {
            int code = connection.getResponseCode();
            if (code == 401 || code == 403) throw new IOException("السيرفر رفض الدخول. راجع بيانات الاشتراك.");
            if (code < 200 || code >= 300) throw new IOException("السيرفر رجّع خطأ (" + code + ").");
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (output.size() + count > 24 * 1024 * 1024) throw new IOException("القائمة أكبر من الحد المدعوم.");
                    output.write(buffer, 0, count);
                }
                return new JSONTokener(new String(output.toByteArray(), StandardCharsets.UTF_8).replaceFirst("^\uFEFF", "")).nextValue();
            }
        } finally {
            connection.disconnect();
        }
    }

    private static String encode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
        } catch (java.io.UnsupportedEncodingException impossible) {
            throw new AssertionError(impossible);
        }
    }
}
