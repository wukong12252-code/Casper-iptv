package com.casper.iptv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Set;
import java.util.concurrent.Executors;

final class Artwork {
    private final ExecutorService workers = Executors.newFixedThreadPool(4);
    private volatile boolean paused;
    private volatile int generation;
    private final Set<HttpURLConnection> active = java.util.Collections.newSetFromMap(new ConcurrentHashMap<HttpURLConnection, Boolean>());
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<String, List<ImageView>> pending = new HashMap<>();
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap bitmap) {
            return bitmap.getAllocationByteCount();
        }
    };

    void show(ImageView view, String address, int maxSide) {
        String key = maxSide + ":" + address;
        Object previous = view.getTag();
        if (previous != null && pending.containsKey(previous)) pending.get(previous).remove(view);
        view.setTag(key);
        view.setImageDrawable(null);
        if (!address.startsWith("https://") && !address.startsWith("http://")) return;
        Bitmap loaded = cache.get(key);
        if (loaded != null) {
            view.setImageBitmap(loaded);
            return;
        }
        if (paused) return;
        List<ImageView> waiting = pending.get(key);
        if (waiting != null) {
            waiting.add(view);
            return;
        }
        if (pending.size() >= 80) return;
        List<ImageView> targets = new ArrayList<>();
        targets.add(view);
        pending.put(key, targets);
        int started = generation;
        workers.execute(() -> {
            if (paused || started != generation) return;
            Bitmap bitmap = read(address, maxSide);
            ui.post(() -> {
                if (paused || started != generation) return;
                List<ImageView> current = pending.remove(key);
                if (current == null || bitmap == null) return;
                cache.put(key, bitmap);
                for (ImageView target : current) {
                    if (key.equals(target.getTag())) target.setImageBitmap(bitmap);
                }
            });
        });
    }

    private Bitmap read(String address, int maxSide) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            active.add(connection);
            if (paused) return null;
            connection.setConnectTimeout(4500);
            connection.setReadTimeout(5000);
            if (connection.getResponseCode() != 200) return null;
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (paused || Thread.currentThread().isInterrupted()
                            || bytes.size() + count > 4 * 1024 * 1024) return null;
                    bytes.write(buffer, 0, count);
                }
                byte[] data = bytes.toByteArray();
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, options);
                options.inJustDecodeBounds = false;
                options.inSampleSize = 1;
                while (Math.max(options.outWidth, options.outHeight) / options.inSampleSize > maxSide * 2) {
                    options.inSampleSize *= 2;
                }
                return BitmapFactory.decodeByteArray(data, 0, data.length, options);
            }
        } catch (Exception ignored) {
            return null;
        } finally {
            if (connection != null) {
                active.remove(connection);
                connection.disconnect();
            }
        }
    }

    void pause() {
        paused = true;
        generation++;
        pending.clear();
        for (HttpURLConnection connection : active) connection.disconnect();
    }

    void resume() {
        paused = false;
    }

    void close() {
        pause();
        workers.shutdownNow();
        pending.clear();
        cache.evictAll();
    }
}
