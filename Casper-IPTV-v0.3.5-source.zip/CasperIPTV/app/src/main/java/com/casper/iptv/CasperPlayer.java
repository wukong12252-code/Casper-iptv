package com.casper.iptv;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.analytics.AnalyticsListener;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

/**
 * ExoPlayer-backed drop-in viewer. Isolates playback logic from the account,
 * favorites, catalog and playback UI maintained in MainActivity.
 *
 * Decoder fallback covers decoder initialization failure, while smooth frame
 * rendering still depends on the media codec and device: no fake guarantees.
 */
final class CasperPlayer extends FrameLayout {
    interface PreparedListener { void onPrepared(); }
    interface PlaybackErrorListener { boolean onError(int what, int extra); }
    interface InfoListener { boolean onInfo(int what, int extra); }
    interface CompletionListener { void onComplete(); }

    private static final String TAG = "CasperPlayback";
    private final ExoPlayer engine;
    private final PlayerView view;
    private PreparedListener preparedListener;
    private PlaybackErrorListener errorListener;
    private InfoListener infoListener;
    private CompletionListener completionListener;
    private boolean preparedNotified;
    private long droppedFrames;

    CasperPlayer(Context context) {
        super(context);
        setBackgroundColor(android.graphics.Color.BLACK);
        // SurfaceView avoids extra texture copies and is the efficient default
        // for high-resolution video; compatibility decoders are also enabled.
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(context)
                .setEnableDecoderFallback(true);
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(15_000, 50_000, 1_500, 2_500)
                .build();
        engine = new ExoPlayer.Builder(context)
                .setRenderersFactory(renderers)
                .setLoadControl(loadControl)
                .build();
        engine.setAudioAttributes(new AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setUsage(C.USAGE_MEDIA)
                .build(), true);
        engine.setPlaybackSpeed(1.0f);
        view = new PlayerView(context);
        view.setUseController(false); // Casper IPTV draws its own TV/phone controls.
        view.setClickable(false);
        view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        view.setPlayer(engine);
        addView(view, new FrameLayout.LayoutParams(-1, -1));
        engine.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) {
                    if (infoListener != null) infoListener.onInfo(MediaPlayer.MEDIA_INFO_BUFFERING_START, 0);
                } else if (state == Player.STATE_READY) {
                    if (infoListener != null) infoListener.onInfo(MediaPlayer.MEDIA_INFO_BUFFERING_END, 0);
                    if (!preparedNotified) {
                        preparedNotified = true;
                        if (preparedListener != null) preparedListener.onPrepared();
                    }
                } else if (state == Player.STATE_ENDED) {
                    if (completionListener != null) completionListener.onComplete();
                }
            }
            @Override public void onPlayerError(@NonNull PlaybackException error) {
                Log.w(TAG, "Playback failed; trying alternate stream where available. Code " + error.getErrorCodeName());
                if (errorListener != null) errorListener.onError(MediaPlayer.MEDIA_ERROR_UNKNOWN, error.errorCode);
            }
        });
        engine.addAnalyticsListener(new AnalyticsListener() {
            @Override public void onDroppedVideoFrames(@NonNull EventTime eventTime,
                    int dropped, long elapsedMs) {
                droppedFrames += dropped;
                if (droppedFrames >= 30) {
                    Log.w(TAG, "Video frame drops: " + droppedFrames
                            + "; audio can stay normal while picture looks slow");
                }
            }
        });
    }

    void setOnPreparedListener(PreparedListener callback) { preparedListener = callback; }
    void setOnErrorListener(PlaybackErrorListener callback) { errorListener = callback; }
    void setOnInfoListener(InfoListener callback) { infoListener = callback; }
    void setOnCompletionListener(CompletionListener callback) { completionListener = callback; }

    void setVideoURI(Uri url) {
        preparedNotified = false;
        droppedFrames = 0;
        engine.stop();
        engine.clearMediaItems();
        engine.setMediaItem(MediaItem.fromUri(url));
        engine.setPlaybackSpeed(1.0f);
        engine.prepare();
    }
    void start() { engine.play(); }
    void pause() { engine.pause(); }
    boolean isPlaying() { return engine.isPlaying(); }
    boolean canSeekBackward() { return engine.isCurrentMediaItemSeekable(); }
    boolean canSeekForward() { return engine.isCurrentMediaItemSeekable(); }
    int getDuration() { return safeMillis(engine.getDuration()); }
    int getCurrentPosition() { return safeMillis(engine.getCurrentPosition()); }
    void seekTo(int positionMs) { engine.seekTo(Math.max(0, positionMs)); }
    long getDroppedVideoFrames() { return droppedFrames; }

    void stopPlayback() {
        view.setPlayer(null);
        preparedListener = null;
        errorListener = null;
        infoListener = null;
        completionListener = null;
        engine.release();
    }

    private static int safeMillis(long millis) {
        return millis == C.TIME_UNSET || millis < 0 ? 0 : (int) Math.min(millis, Integer.MAX_VALUE);
    }
}
