package com.casper.iptv;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class MainActivity extends Activity {
    private static final int BACKGROUND = 0xff344caa;
    private static final int PANEL = 0xff365b96;
    private static final int TEXT = 0xfff5f3ed;
    private static final int MUTED = 0xffe1eaff;
    private static final int ACCENT = 0xffffbf66;

    private enum Section {
        LIVE("مباشر", "get_live_categories", "get_live_streams", "live"),
        MOVIES("أفلام", "get_vod_categories", "get_vod_streams", "movie"),
        SERIES("مسلسلات", "get_series_categories", "get_series", "series");

        final String label;
        final String categoryAction;
        final String itemAction;
        final String streamKind;

        Section(String label, String categoryAction, String itemAction, String streamKind) {
            this.label = label;
            this.categoryAction = categoryAction;
            this.itemAction = itemAction;
            this.streamKind = streamKind;
        }
    }

    private static final class Entry {
        final String id;
        final String title;
        final String extension;
        final String art;
        final String backdrop;
        final String plot;
        final long added;
        final JSONObject metadata;

        Entry(String id, String title, String extension) {
            this(id, title, extension, "", "", "", 0);
        }

        Entry(String id, String title, String extension, String art, String backdrop, String plot, long added) {
            this(id, title, extension, art, backdrop, plot, added, new JSONObject());
        }

        Entry(String id, String title, String extension, String art, String backdrop, String plot, long added, JSONObject metadata) {
            this.id = id;
            this.title = title;
            this.extension = extension;
            this.art = art;
            this.backdrop = backdrop;
            this.plot = plot;
            this.added = added;
            this.metadata = metadata;
        }
    }

    private static final Entry ALL = new Entry(null, "كل المحتوى", "");
    private static final Entry FAVORITES = new Entry(null, "المفضلة", "");
    private static final Entry RECENT = new Entry(null, "أضيف حديثًا", "");
    private static final Entry RESUME = new Entry(null, "استكمال المشاهدة", "");

    private static final class Tile {
        final Section section;
        final Entry entry;
        final int position;
        final int duration;

        Tile(Section section, Entry entry, int position, int duration) {
            this.section = section;
            this.entry = entry;
            this.position = position;
            this.duration = duration;
        }

        String key() {
            return section.name() + "/" + entry.id;
        }
    }

    private static final class HomeResult {
        final List<Tile> tiles;
        final List<Tile> live;
        final boolean partial;

        HomeResult(List<Tile> tiles, List<Tile> live, boolean partial) {
            this.tiles = tiles;
            this.live = live;
            this.partial = partial;
        }
    }

    private interface Result<T> {
        void accept(T result);
    }

    private final Artwork artwork = new Artwork();
    private final Map<String, Tile> favorites = new LinkedHashMap<>();
    private final Map<String, Tile> history = new LinkedHashMap<>();
    private SharedPreferences watchData;
    private AccountStore accountStore;
    private boolean loginVisible;
    private String accountKey;
    private List<Tile> recent = Collections.emptyList();
    private List<Tile> homeLive = Collections.emptyList();
    private boolean home;
    private boolean latest;
    private String catalogMessage;
    private Runnable catalogRetry;
    private String searchTerm = "";
    private enum Order {
        SERVER("ترتيب السيرفر"),
        TITLE_ASC("أبجدي تصاعدي · A–Z"),
        TITLE_DESC("أبجدي تنازلي · Z–A"),
        NEWEST("الأحدث إضافةً أولًا"),
        OLDEST("الأقدم إضافةً أولًا");

        final String label;
        Order(String label) { this.label = label; }
    }

    private Order itemOrder = Order.SERVER;
    private Order categoryOrder = Order.SERVER;
    private int catalogSelection;
    private final ExecutorService network = Executors.newCachedThreadPool();
    private Future<?> request;
    private final Handler searchHandler = new Handler();
    private final Map<Section, List<Entry>> searchCatalogs = new java.util.EnumMap<>(Section.class);
    private CatalogSearch currentSearch;
    private int requestVersion;
    private boolean tv;
    private XtreamClient client;
    private String accountName = "";
    private Section section = Section.LIVE;
    private List<Entry> categories = Collections.emptyList();
    private Entry category;
    private List<Entry> items = Collections.emptyList();
    private Entry series;
    private List<Entry> episodes = Collections.emptyList();
    private boolean viewingEpisodes;
    private CasperPlayer player;
    private Button playPause;
    private TextView playbackStatus;
    private String[] playbackUrls;
    private int playbackAttempt;
    private boolean playbackLive;
    private Tile playingTile;
    private boolean playbackPrepared;
    private boolean playbackCompleted;
    private boolean dragging;
    private SeekBar timeline;
    private View timelineRow;
    private TextView elapsed;
    private TextView total;
    private FrameLayout playerSurface;
    private View playerHeader;
    private View playerTransport;
    private boolean playbackSeekable;
    private int previousSystemUi;
    private int previousOrientation;
    private int previousCutoutMode;
    private final Runnable hideControls = this::hidePlayerControls;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player == null || !playbackPrepared) return;
            if (!dragging && playerTransport.getVisibility() == View.VISIBLE) {
                updateTimeline(playbackCompleted ? player.getDuration() : player.getCurrentPosition());
            }
            player.postDelayed(this, playerTransport.getVisibility() == View.VISIBLE ? 500 : 1500);
        }
    };

    @Override
    public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        UiModeManager mode = (UiModeManager) getSystemService(UI_MODE_SERVICE);
        tv = mode.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION
                || getPackageManager().hasSystemFeature("android.software.leanback");
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        accountStore = new AccountStore(this);
        showLogin();
        restoreLastAccount();
    }

    private void restoreLastAccount() {
        JSONArray saved;
        try {
            saved = accountStore.list();
        } catch (Exception unavailable) {
            android.widget.Toast.makeText(this, "تعذّر قراءة الحسابات المحفوظة على الجهاز.",
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        String active = accountStore.activeKey();
        if (active == null && saved.length() == 1) {
            switchAccount(saved.optJSONObject(0));
            return;
        }
        for (int i = 0; i < saved.length(); i++) {
            JSONObject account = saved.optJSONObject(i);
            if (account.optString("key").equals(active)) {
                switchAccount(account);
                return;
            }
        }
    }

    private void showLogin() {
        if (currentSearch != null) currentSearch.cancel();
        currentSearch = null;
        cancelRequest();
        loginVisible = true;
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xff167fa0, BACKGROUND, 0xff8850bf}));
        ScrollView scroll = new ScrollView(this) {
            @Override
            protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
                super.onSizeChanged(width, height, oldWidth, oldHeight);
                int gutter = Math.max(0, (width - dp(tv ? 610 : 490)) / 2);
                if (gutter != getPaddingLeft()) setPadding(gutter, 0, gutter, 0);
            }
        };
        scroll.setFillViewport(true);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout form = column();
        form.setPadding(dp(tv ? 24 : 20), dp(tv ? 18 : 26), dp(tv ? 24 : 20), dp(18));
        scroll.addView(form);
        LinearLayout brand = brandMark(tv ? 34 : 32);
        brand.setGravity(Gravity.CENTER);
        form.addView(brand);
        TextView subtitle = label("تسجيل الدخول · Xtream Codes", 16, MUTED);
        subtitle.setGravity(Gravity.CENTER);
        form.addView(subtitle, marginBelow(tv ? 10 : 19));

        EditText name = field("اسم الاشتراك (اختياري)", InputType.TYPE_CLASS_TEXT, true);
        EditText user = field("اليوزر", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS, false);
        EditText pass = field("الباسورد", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD, false);
        EditText url = field("رابط السيرفر (URL)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, false);
        EditText port = field("البورت (اختياري)", InputType.TYPE_CLASS_NUMBER, false);
        EditText[] fields = {name, user, pass, url, port};
        for (EditText input : fields) form.addView(input, marginBelow(5));
        CheckBox reveal = new CheckBox(this);
        reveal.setText("إظهار الباسورد");
        reveal.setTextColor(MUTED);
        reveal.setButtonTintList(ColorStateList.valueOf(ACCENT));
        reveal.setId(View.generateViewId());
        reveal.setBackground(inputSurface());
        reveal.setPadding(dp(10), 0, dp(10), 0);
        form.addView(reveal, marginBelow(6));
        reveal.setOnCheckedChangeListener((button, checked) -> {
            pass.setInputType(InputType.TYPE_CLASS_TEXT | (checked
                    ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            pass.setSelection(pass.length());
        });
        Button login = action("تسجيل الدخول");
        form.addView(login, marginBelow(4));
        for (int i = 0; i < fields.length; i++) {
            View next = i + 1 < fields.length ? fields[i + 1] : reveal;
            fields[i].setNextFocusDownId(next.getId());
            if (i > 0) fields[i].setNextFocusUpId(fields[i - 1].getId());
        }
        reveal.setNextFocusDownId(login.getId());
        reveal.setNextFocusUpId(port.getId());
        login.setNextFocusUpId(reveal.getId());

        TextView status = label("", 14, MUTED);
        status.setGravity(Gravity.CENTER);
        form.addView(status);
        Button savedAccounts = action("الحسابات المحفوظة");
        savedAccounts.setOnClickListener(view -> pickAccounts());
        form.addView(savedAccounts, marginBelow(5));
        TextView savedNote = label("الحسابات بتتحفظ مشفّرة على الجهاز للتبديل بينها.", 12, MUTED);
        savedNote.setGravity(Gravity.CENTER);
        form.addView(savedNote);
        login.setOnClickListener(view -> {
            String username = user.getText().toString().trim();
            String password = pass.getText().toString();
            if (username.isEmpty() || password.isEmpty()) {
                status.setText("اكتب اليوزر والباسورد.");
                (username.isEmpty() ? user : pass).requestFocus();
                return;
            }
            XtreamClient candidate;
            try {
                candidate = new XtreamClient(url.getText().toString(), port.getText().toString(), username, password);
            } catch (IllegalArgumentException error) {
                status.setText(error.getMessage());
                url.requestFocus();
                return;
            }
            String display = name.getText().toString().trim();
            String serverAddress = url.getText().toString().trim();
            String serverPort = port.getText().toString().trim();
            hideKeyboard();
            login.setEnabled(false);
            status.setText("جاري تسجيل الدخول…");
            fetch(() -> {
                candidate.signIn();
                try {
                    accountStore.save(candidate.accountKey(), display, serverAddress,
                            serverPort, username, password);
                } catch (Exception storageError) {
                    throw new IOException("حفظ الحساب تعذّر على الجهاز. حاول تاني.");
                }
                return candidate;
            }, connected -> {
                pass.setText("");
                enterAccount(connected, display.isEmpty() ? username : display);
            }, message -> {
                status.setText(message);
                login.setEnabled(true);
                login.requestFocus();
            });
        });
        setContentView(root);
        if (tv) user.requestFocus();
        else {
            form.setFocusableInTouchMode(true);
            form.requestFocus();
        }
    }

    private void openSection(Section selected) {
        loginVisible = false;
        home = false;
        latest = false;
        searchTerm = "";
        catalogSelection = 0;
        section = selected;
        itemOrder = readOrder("item_order_" + selected.name());
        categoryOrder = readOrder("category_order_" + selected.name());
        category = null;
        categories = Collections.emptyList();
        items = Collections.emptyList();
        series = null;
        viewingEpisodes = false;
        showCatalog("جاري تحميل التصنيفات…", null);
        XtreamClient active = client;
        fetch(() -> entries(active.list(selected.categoryAction, null), "category_id", "category_name"),
                loaded -> {
                    categories = loaded;
                    loadCategory(ALL);
                }, error -> showCatalog(error, () -> openSection(selected)));
    }

    private void loadCategory(Entry selected) {
        category = selected;
        searchTerm = "";
        catalogSelection = 0;
        items = Collections.emptyList();
        searchCatalogs.remove(section);
        viewingEpisodes = false;
        Section activeSection = section;
        XtreamClient active = client;
        if (selected == FAVORITES || selected == RESUME) {
            refreshLocalCategory();
            showCatalog(items.isEmpty() ? "القائمة فاضية." : null, null);
            return;
        }
        showCatalog("جاري تحميل القائمة…", null);
        fetch(() -> entries(active.list(activeSection.itemAction, selected.id),
                        activeSection == Section.SERIES ? "series_id" : "stream_id", "name"),
                loaded -> {
                    items = selected.id == null ? loaded : categoryEntries(loaded, selected.id);
                    if (selected == ALL || selected == RECENT) searchCatalogs.put(activeSection, loaded);
                    if (selected == RECENT) itemOrder = Order.NEWEST;
                    showCatalog(items.isEmpty() ? "القائمة فاضية." : null, null);
                }, error -> showCatalog(error, () -> loadCategory(selected)));
    }

    private void openSeries(Entry chosen) {
        searchTerm = "";
        catalogSelection = 0;
        series = chosen;
        viewingEpisodes = true;
        episodes = Collections.emptyList();
        showCatalog("جاري تحميل الحلقات…", null);
        XtreamClient active = client;
        fetch(() -> getEpisodes(active.seriesInfo(chosen.id)),
                loaded -> {
                    episodes = loaded;
                    showCatalog(episodes.isEmpty() ? "مفيش حلقات متاحة." : null, null);
                }, error -> showCatalog(error, () -> openSeries(chosen)));
    }

    private LinearLayout brandMark(int size) {
        LinearLayout mark = row();
        mark.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.casper_icon);
        mark.addView(icon, new LinearLayout.LayoutParams(dp(size + 10), dp(size + 10)));
        TextView name = label("CASPER", size, TEXT);
        name.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        name.setLetterSpacing(0.06f);
        mark.addView(name);
        TextView tag = label(" IPTV ", Math.max(11, size / 2), ACCENT);
        tag.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tag.setLetterSpacing(0.08f);
        tag.setPadding(dp(5), dp(3), dp(5), dp(3));
        GradientDrawable border = shape(0xff314d8d);
        border.setStroke(dp(1), ACCENT);
        tag.setBackground(border);
        LinearLayout.LayoutParams spacing = new LinearLayout.LayoutParams(-2, -2);
        spacing.leftMargin = dp(7);
        mark.addView(tag, spacing);
        mark.setContentDescription("Casper IPTV");
        return mark;
    }

    private View dashboard() {
        LinearLayout board = column();
        LinearLayout shortcuts = row();
        for (Section type : Section.values()) {
            LinearLayout card = column();
            card.setGravity(Gravity.CENTER);
            card.setPadding(dp(14), dp(16), dp(14), dp(16));
            card.setBackground(inputSurface());
            card.setFocusable(true);
            String symbol = type == Section.LIVE ? "▣" : type == Section.MOVIES ? "▶" : "▤";
            TextView icon = label(symbol, 35, ACCENT);
            icon.setGravity(Gravity.CENTER);
            card.addView(icon);
            TextView title = label(type == Section.LIVE ? "تلفزيون مباشر" : type.label, 22, TEXT);
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            card.addView(title);
            card.setContentDescription(type.label);
            card.setOnClickListener(view -> openSection(type));
            LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(0, dp(138), 1);
            layout.setMargins(dp(4), 0, dp(4), 0);
            shortcuts.addView(card, layout);
        }
        board.addView(shortcuts, marginBelow(10));
        LinearLayout account = row();
        TextView identity = label("الاشتراك الحالي · " + accountName, 14, TEXT);
        identity.setMaxLines(1);
        identity.setEllipsize(TextUtils.TruncateAt.END);
        account.addView(identity, new LinearLayout.LayoutParams(0, -2, 1));
        TextView dates = label("تاريخ البدء · " + subscriptionDate("created_at")
                + "     انتهاء الاشتراك · " + subscriptionDate("exp_date"), 13, MUTED);
        dates.setGravity(Gravity.RIGHT);
        account.addView(dates, new LinearLayout.LayoutParams(0, -2, 2));
        board.addView(account, marginBelow(5));
        TextView today = label(new java.text.SimpleDateFormat("dd/MM/yyyy   HH:mm", Locale.getDefault())
                .format(new java.util.Date()), 12, MUTED);
        today.setGravity(Gravity.RIGHT);
        board.addView(today);
        return board;
    }

    private String subscriptionDate(String field) {
        long seconds = client == null ? 0 : client.userInfo().optLong(field, 0);
        if (seconds <= 0 || seconds > 253402300799L) return "غير متوفر من السيرفر";
        return new java.text.SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                .format(new java.util.Date(seconds * 1000));
    }

    private void enterAccount(XtreamClient connected, String name) {
        client = connected;
        searchCatalogs.clear();
        accountName = name;
        watchData = getSharedPreferences("watch_data", MODE_PRIVATE);
        accountKey = connected.accountKey();
        if (!accountStore.rememberActive(accountKey)) {
            android.widget.Toast.makeText(this, "الدخول نجح، لكن حفظ آخر حساب تعذّر.",
                    android.widget.Toast.LENGTH_LONG).show();
        }
        recent = Collections.emptyList();
        homeLive = Collections.emptyList();
        categories = Collections.emptyList();
        items = Collections.emptyList();
        episodes = Collections.emptyList();
        category = null;
        restoreTiles("favorites", favorites);
        restoreTiles("history", history);
        openHome(false, true);
    }

    private void showAccountMenu() {
        new AlertDialog.Builder(this).setTitle(accountName.isEmpty() ? "الحساب" : accountName)
                .setItems(new String[]{"بيانات الاشتراك", "تبديل الحساب", "إضافة حساب", "تسجيل خروج"}, (dialog, which) -> {
                    if (which == 0) subscriptionDetails();
                    if (which == 1) pickAccounts();
                    if (which == 2) showLogin();
                    if (which == 3) confirmLogout();
                }).setNegativeButton("رجوع", null).show();
    }

    private void subscriptionDetails() {
        JSONObject info = client.userInfo();
        String status = cleanString(info, "status");
        String connections = cleanString(info, "max_connections");
        new AlertDialog.Builder(this).setTitle("بيانات الاشتراك")
                .setMessage("اسم الاشتراك · " + accountName
                        + "\nالحالة · " + ("Active".equalsIgnoreCase(status) ? "نشط" : status.isEmpty() ? "غير متوفرة" : status)
                        + "\nتاريخ البدء · " + subscriptionDate("created_at")
                        + "\nتاريخ الانتهاء · " + subscriptionDate("exp_date")
                        + (connections.isEmpty() ? "" : "\nالاتصالات المسموحة حسب السيرفر · " + connections))
                .setPositiveButton("تمام", null).show();
    }

    private void pickAccounts() {
        JSONArray accounts;
        try {
            accounts = accountStore.list();
        } catch (Exception error) {
            new AlertDialog.Builder(this).setMessage("تعذّر قراءة الحسابات المحفوظة على الجهاز.")
                    .setPositiveButton("تمام", null).show();
            return;
        }
        String[] names = new String[accounts.length()];
        for (int i = 0; i < accounts.length(); i++) {
            JSONObject account = accounts.optJSONObject(i);
            names[i] = account.optString("name") + (account.optString("key").equals(accountKey) && client != null ? "  • الحالي" : "");
        }
        AlertDialog.Builder picker = new AlertDialog.Builder(this).setTitle("الحسابات المحفوظة");
        if (names.length == 0) picker.setMessage("مفيش حسابات محفوظة. أضف حسابك الأول.");
        else picker.setItems(names, (dialog, index) -> {
            JSONObject selected = accounts.optJSONObject(index);
            new AlertDialog.Builder(this).setTitle(selected.optString("name"))
                    .setPositiveButton("دخول", (choice, which) -> switchAccount(selected))
                    .setNeutralButton("حذف من الجهاز", (choice, which) -> {
                        new AlertDialog.Builder(this).setMessage("تحذف بيانات الحساب المحفوظة من الجهاز؟")
                                .setPositiveButton("حذف", (confirmation, button) -> {
                                    try {
                                        accountStore.remove(selected.optString("key"));
                                        pickAccounts();
                                    } catch (Exception error) {
                                        android.widget.Toast.makeText(this, "تعذّر حذف الحساب.", android.widget.Toast.LENGTH_SHORT).show();
                                    }
                                }).setNegativeButton("رجوع", null).show();
                    }).setNegativeButton("رجوع", null).show();
        });
        picker.setPositiveButton("إضافة حساب", (dialog, which) -> showLogin())
                .setNegativeButton("رجوع", null).show();
    }

    private void switchAccount(JSONObject account) {
        XtreamClient candidate;
        try {
            candidate = new XtreamClient(account.optString("url"), account.optString("port"),
                    account.optString("user"), account.optString("password"));
        } catch (IllegalArgumentException invalid) {
            android.widget.Toast.makeText(this, "بيانات الحساب المحفوظة غير صالحة. أضفه من جديد.", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        Runnable cancelSwitch = () -> {
            cancelRequest();
            if (client != null) openHome(false, false);
            else showLogin();
        };
        AlertDialog progress = new AlertDialog.Builder(this).setMessage("جاري الدخول للحساب…")
                .setNegativeButton("إلغاء", (dialog, which) -> cancelSwitch.run()).create();
        progress.setOnCancelListener(dialog -> cancelSwitch.run());
        progress.show();
        fetch(() -> {
            candidate.signIn();
            return candidate;
        }, connected -> {
            progress.dismiss();
            enterAccount(connected, account.optString("name"));
        }, error -> {
            progress.dismiss();
            if (client != null && !loginVisible) openHome(false, false);
            new AlertDialog.Builder(this).setMessage(error)
                    .setPositiveButton("إعادة المحاولة", (dialog, which) -> switchAccount(account))
                    .setNeutralButton("تعديل البيانات", (dialog, which) -> showLogin())
                    .setNegativeButton("رجوع", null).show();
        });
    }

    private void settings() {
        new AlertDialog.Builder(this).setTitle("الإعدادات")
                .setItems(new String[]{"مدة ظهور أدوات المشغّل", "الحسابات المحفوظة", "مسح سجل المشاهدة"}, (dialog, which) -> {
                    if (which == 0) {
                        SharedPreferences preferences = getSharedPreferences("settings", MODE_PRIVATE);
                        int[] durations = {3500, 5000, 8000};
                        int checked = 0;
                        for (int i = 0; i < durations.length; i++) {
                            if (preferences.getInt("controls_ms", 3500) == durations[i]) checked = i;
                        }
                        new AlertDialog.Builder(this).setTitle("مدة ظهور أدوات المشغّل")
                                .setSingleChoiceItems(new String[]{"٣٫٥ ثانية", "٥ ثواني", "٨ ثواني"}, checked, (choice, index) -> {
                                    preferences.edit().putInt("controls_ms", durations[index]).apply();
                                    choice.dismiss();
                                }).setNegativeButton("رجوع", null).show();
                    }
                    if (which == 1) pickAccounts();
                    if (which == 2) {
                        new AlertDialog.Builder(this).setMessage("تمسح سجل مشاهدة الحساب الحالي؟")
                                .setPositiveButton("مسح", (confirmation, button) -> {
                                    history.clear();
                                    saveTiles("history", history);
                                    if (home) showHome(catalogMessage);
                                    else {
                                        refreshLocalCategory();
                                        showCatalog(null, null);
                                    }
                                }).setNegativeButton("رجوع", null).show();
                    }
                }).setNegativeButton("رجوع", null).show();
    }

    private boolean wideLayout() {
        return tv || getResources().getConfiguration().screenWidthDp >= 620;
    }

    private LinearLayout navigation() {
        LinearLayout heading = row();
        boolean compact = !tv && getResources().getConfiguration().screenWidthDp < 900;
        LinearLayout brand = brandMark(compact ? 19 : 24);
        heading.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        if (wideLayout()) heading.addView(tabs(), new LinearLayout.LayoutParams(0, -2, 2.2f));
        Button refresh = action("↻");
        refresh.setContentDescription("تحديث");
        refresh.setOnClickListener(view -> {
            searchCatalogs.remove(section);
            if (viewingEpisodes && series != null) openSeries(series);
            else if (home) openHome(latest, true);
            else if (category == null) openSection(section);
            else loadCategory(category);
        });
        heading.addView(refresh, new LinearLayout.LayoutParams(dp(43), -2));
        Button account = action(!compact && !accountName.isEmpty() ? accountName : "الحساب");
        account.setMaxWidth(dp(132));
        account.setMinWidth(dp(66));
        account.setSingleLine(true);
        account.setEllipsize(TextUtils.TruncateAt.END);
        account.setOnClickListener(view -> showAccountMenu());
        heading.addView(account);
        Button settings = action("⚙");
        settings.setContentDescription("الإعدادات");
        settings.setOnClickListener(view -> settings());
        heading.addView(settings, new LinearLayout.LayoutParams(dp(43), -2));
        return heading;
    }

    private LinearLayout tabs() {
        LinearLayout tabs = row();
        addTab(tabs, "الرئيسية", home && !latest, () -> openHome(false, false));
        for (Section tab : Section.values()) {
            addTab(tabs, tab.label, !home && tab == section, () -> openSection(tab));
        }
        addTab(tabs, "الأحدث", home && latest, () -> openHome(true, false));
        return tabs;
    }

    private void addTab(LinearLayout tabs, String title, boolean selected, Runnable open) {
        Button button = action(title);
        button.setSingleLine(true);
        button.setTextSize(wideLayout() ? 14 : 12);
        button.setPadding(dp(2), dp(4), dp(2), dp(4));
        button.setSelected(selected);
        button.setOnClickListener(view -> open.run());
        tabs.addView(button, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private LinearLayout shell() {
        LinearLayout root = page();
        root.addView(navigation(), marginBelow(6));
        if (!wideLayout()) root.addView(tabs(), marginBelow(6));
        return root;
    }

    private void addBody(LinearLayout root, View content) {
        LinearLayout body = row();
        body.setGravity(Gravity.TOP);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        if (wideLayout()) {
            LinearLayout rail = column();
            addShortcut(rail, "⌂", "الرئيسية", () -> openHome(false, false));
            addShortcut(rail, "▣", "مباشر", () -> openSection(Section.LIVE));
            addShortcut(rail, "▶", "أفلام", () -> openSection(Section.MOVIES));
            addShortcut(rail, "▤", "مسلسلات", () -> openSection(Section.SERIES));
            addShortcut(rail, "◷", "الأحدث", () -> openHome(true, false));
            LinearLayout.LayoutParams size = new LinearLayout.LayoutParams(dp(42), -2);
            size.rightMargin = dp(7);
            body.addView(rail, size);
        }
        body.addView(content, 0, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private void addShortcut(LinearLayout rail, String icon, String title, Runnable open) {
        Button button = action(icon);
        button.setTextSize(19);
        button.setPadding(0, 0, 0, 0);
        button.setContentDescription(title);
        button.setOnClickListener(view -> open.run());
        rail.addView(button, marginBelow(6));
    }

    private void openHome(boolean latestOnly, boolean reload) {
        if (currentSearch != null) currentSearch.cancel();
        currentSearch = null;
        cancelRequest();
        loginVisible = false;
        home = true;
        latest = latestOnly;
        catalogRetry = null;
        viewingEpisodes = false;
        series = null;
        if (!reload && (!recent.isEmpty() || !homeLive.isEmpty())) {
            showHome(null);
            return;
        }
        showHome("جاري تحميل الرئيسية…");
        XtreamClient active = client;
        fetch(() -> {
            List<Tile> combined = new ArrayList<>();
            Exception failure = null;
            for (Section type : new Section[]{Section.MOVIES, Section.SERIES}) {
                try {
                    List<Entry> newest = uniqueHomeEntries(entries(active.list(type.itemAction, null),
                            type == Section.SERIES ? "series_id" : "stream_id", "name"));
                    for (Entry entry : newest.subList(0, Math.min(36, newest.size()))) {
                        combined.add(new Tile(type, entry, 0, 0));
                    }
                } catch (Exception error) {
                    failure = error;
                }
            }
            List<Tile> live = new ArrayList<>();
            Map<String, Tile> unique = new LinkedHashMap<>();
            try {
                List<Entry> groups = entries(active.list(Section.LIVE.categoryAction, null), "category_id", "category_name");
                List<Entry> matched = new ArrayList<>();
                for (Entry group : groups) {
                    if (isBeinSd(group.title)) matched.add(group);
                }
                if (matched.isEmpty()) {
                    for (Entry entry : entries(active.list(Section.LIVE.itemAction, null), "stream_id", "name")) {
                        if (isBeinSd(entry.title)) unique.put(entry.id, new Tile(Section.LIVE, entry, 0, 0));
                    }
                } else {
                    for (Entry group : matched) {
                        for (Entry entry : entries(active.list(Section.LIVE.itemAction, group.id), "stream_id", "name")) {
                            unique.put(entry.id, new Tile(Section.LIVE, entry, 0, 0));
                        }
                    }
                }
            } catch (Exception error) {
                failure = error;
            }
            live.addAll(unique.values());
            if (combined.isEmpty() && live.isEmpty() && failure != null) throw failure;
            Collections.sort(combined, (left, right) -> Long.compare(right.entry.added, left.entry.added));
            return new HomeResult(combined, live, failure != null);
        }, loaded -> {
            recent = loaded.tiles;
            homeLive = loaded.live;
            showHome(loaded.partial ? "بعض الأقسام متعذّر تحميلها. استخدم تحديث للمحاولة تاني."
                    : recent.isEmpty() && homeLive.isEmpty() ? "مفيش عناوين متاحة." : null);
        }, this::showHome);
    }

    private static String titleKey(String title) {
        return java.text.Normalizer.normalize(title, java.text.Normalizer.Form.NFKC)
                .trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private static List<Entry> uniqueCatalogEntries(List<Entry> original) {
        Map<String, Entry> unique = new LinkedHashMap<>();
        for (Entry entry : original) {
            String key = titleKey(entry.title);
            Entry previous = unique.get(key);
            if (previous == null || entry.added > previous.added) unique.put(key, entry);
        }
        return new ArrayList<>(unique.values());
    }

    private static List<Entry> uniqueHomeEntries(List<Entry> original) {
        return orderedEntries(uniqueCatalogEntries(original), Order.NEWEST);
    }

    private static boolean isBeinSd(String name) {
        String value = name.toLowerCase(Locale.ROOT);
        String compact = value.replaceAll("\\s+", "");
        boolean bein = compact.contains("bein") || compact.contains("بيان") || compact.contains("بيإن");
        return bein && java.util.regex.Pattern.compile("(^|[^a-z])sd([^a-z]|$)").matcher(value).find();
    }

    private static List<Tile> sectionTiles(List<Tile> tiles, Section section) {
        List<Tile> selected = new ArrayList<>();
        for (Tile tile : tiles) if (tile.section == section) selected.add(tile);
        return selected;
    }

    private void showHome(String notice) {
        catalogMessage = notice;
        LinearLayout root = shell();
        if (latest) {
            LinearLayout content = column();
            addBody(root, content);
            content.addView(sectionHeading("أضيف حديثًا"), marginBelow(5));
            if (notice != null) content.addView(label(notice, 15, MUTED), marginBelow(5));
            GridView grid = grid(false);
            grid.setAdapter(new EntryAdapter(recent, false));
            grid.setOnItemClickListener((parent, view, index, id) -> activate(recent.get(index)));
            grid.setOnItemLongClickListener((parent, view, index, id) -> {
                toggleFavorite(recent.get(index));
                return true;
            });
            content.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
            setContentView(root);
            if (tv && !recent.isEmpty()) grid.requestFocus();
            return;
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        LinearLayout feed = column();
        scroll.addView(feed);
        addBody(root, scroll);
        feed.addView(dashboard(), marginBelow(14));
        addShelf(feed, "مباشر · beIN Sports SD", homeLive, false);
        if (!recent.isEmpty()) feed.addView(featured(recent.get(0)), marginBelow(9));
        if (notice != null) feed.addView(label(notice, 15, MUTED), marginBelow(7));

        List<Tile> watching = new ArrayList<>(history.values());
        Collections.reverse(watching);
        addShelf(feed, "كمّل المشاهدة", watching, true);
        addShelf(feed, "أفلام أضيفت حديثًا", sectionTiles(recent, Section.MOVIES), false);
        addShelf(feed, "مسلسلات أضيفت حديثًا", sectionTiles(recent, Section.SERIES), false);
        if (!favorites.isEmpty()) addShelf(feed, "المفضلة", new ArrayList<>(favorites.values()), false);
        setContentView(root);
    }

    private View featured(Tile tile) {
        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(shape(0xff263650));
        hero.setClipToOutline(true);
        hero.setMinimumHeight(dp(wideLayout() ? 220 : 210));
        ImageView scenery = new ImageView(this);
        scenery.setImageResource(R.drawable.casper_landscape);
        scenery.setScaleType(ImageView.ScaleType.FIT_XY);
        hero.addView(scenery, new FrameLayout.LayoutParams(-1, -1));
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.addView(image, new FrameLayout.LayoutParams(-1, -1));
        artwork.show(image, client.artworkUrl(tile.entry.backdrop.isEmpty() ? tile.entry.art : tile.entry.backdrop), 1150);

        View fade = new View(this);
        fade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xf8070d17, 0xb00b1829, 0x28101e2d}));
        hero.addView(fade, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout caption = column();
        caption.setPadding(dp(20), dp(12), dp(16), dp(16));
        TextView type = label(tile.section.label + "   •   أضيف حديثًا", 14, ACCENT);
        caption.addView(type);
        TextView title = label(tile.entry.title, wideLayout() ? 34 : 25, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        caption.addView(title, marginBelow(8));

        LinearLayout controls = row();
        Button watch = action(tile.section == Section.SERIES ? "عرض الحلقات" : "▶ مشاهدة الآن");
        watch.setOnClickListener(view -> activate(tile));
        Button info = action("التفاصيل");
        info.setOnClickListener(view -> details(tile));
        Button save = action(favorites.containsKey(tile.key()) ? "♥ قائمتي" : "＋ قائمتي");
        save.setOnClickListener(view -> {
            toggleFavorite(tile);
            showHome(catalogMessage);
        });
        controls.addView(watch);
        controls.addView(info);
        controls.addView(save);
        caption.addView(controls);
        FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM | Gravity.LEFT);
        hero.addView(caption, layout);
        return hero;
    }

    private void details(Tile tile) {
        LinearLayout content = column();
        content.setPadding(dp(20), dp(16), dp(20), dp(18));
        content.setBackground(shape(BACKGROUND));
        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(wideLayout() ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        ScrollView detailsScroll = new ScrollView(this);
        detailsScroll.addView(summary);
        content.addView(detailsScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        ImageView poster = new ImageView(this);
        poster.setScaleType(ImageView.ScaleType.FIT_CENTER);
        poster.setBackground(shape(PANEL));
        LinearLayout.LayoutParams posterSize = new LinearLayout.LayoutParams(
                dp(wideLayout() ? 160 : 96), dp(wideLayout() ? 270 : 115));
        posterSize.rightMargin = dp(22);
        posterSize.gravity = Gravity.CENTER_HORIZONTAL;
        summary.addView(poster, posterSize);
        artwork.show(poster, client.artworkUrl(tile.entry.art), 450);

        LinearLayout description = column();
        LinearLayout.LayoutParams descriptionSize = wideLayout()
                ? new LinearLayout.LayoutParams(0, -2, 1) : new LinearLayout.LayoutParams(-1, -2);
        summary.addView(description, descriptionSize);
        TextView brand = label("Casper IPTV", 13, ACCENT);
        brand.setGravity(Gravity.RIGHT);
        description.addView(brand, marginBelow(12));
        TextView name = label(tile.entry.title, 23, TEXT);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);
        description.addView(name, marginBelow(8));
        TextView metadata = label(ratingText(tile.entry.metadata), 14, MUTED);
        description.addView(metadata, marginBelow(8));
        Button imdb = action("IMDb ↗");
        imdb.setTextSize(13);
        imdb.setMinHeight(dp(32));
        imdb.setMinimumHeight(dp(32));
        LinearLayout referenceLinks = row();
        description.addView(referenceLinks);
        referenceLinks.addView(imdb, new LinearLayout.LayoutParams(-2, dp(35)));
        Button parents = action("دليل الآباء ↗");
        parents.setTextSize(13);
        parents.setMinHeight(dp(32));
        parents.setMinimumHeight(dp(32));
        referenceLinks.addView(parents, new LinearLayout.LayoutParams(-2, dp(35)));
        parents.setOnClickListener(view -> openParentsGuide(imdbUrl(tile.entry.metadata), tile.entry.title));
        TextView advisory = label("تنبيهات المحتوى لم تُراجَع بعد. افتح دليل الآباء لمراجعتها.", 13, 0xffffc580);
        advisory.setPadding(0, dp(4), 0, dp(4));
        description.addView(advisory, marginBelow(4));
        String catalogImdb = imdbUrl(tile.entry.metadata);
        imdb.setOnClickListener(view -> openBrowser(catalogImdb.isEmpty()
                ? "https://www.imdb.com/find/?q=" + Uri.encode(tile.entry.title) : catalogImdb));
        ScrollView plotScroll = new ScrollView(this);
        TextView plot = label(tile.entry.plot.isEmpty() ? "جاري تحميل التفاصيل…" : tile.entry.plot, 15, MUTED);
        plot.setPadding(0, dp(4), 0, dp(4));
        plotScroll.addView(plot);
        description.addView(plotScroll, new LinearLayout.LayoutParams(-1, dp(wideLayout() ? 60 : 46)));

        LinearLayout buttons = row();
        content.addView(buttons);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        dialog.setOnDismissListener(ignored -> cancelRequest());
        Tile[] current = {tile};
        Tile saved = history.get(tile.key());
        Button watch = action(tile.section == Section.SERIES ? "عرض الحلقات" : saved == null ? "▶ ابدأ من الأول" : "▶ كمّل المشاهدة");
        watch.setTextSize(14);
        watch.setOnClickListener(view -> {
            dialog.dismiss();
            if (tile.section == Section.SERIES) activate(tile);
            else openPlayer(current[0]);
        });
        buttons.addView(watch, new LinearLayout.LayoutParams(0, -2, 1));
        if (saved != null && tile.section == Section.MOVIES) {
            Button restart = action("من الأول");
            restart.setTextSize(13);
            restart.setOnClickListener(view -> {
                dialog.dismiss();
                history.remove(tile.key());
                saveTiles("history", history);
                openPlayer(current[0]);
            });
            buttons.addView(restart);
        }
        Button favorite = action(favorites.containsKey(tile.key()) ? "♥ في المفضلة" : "♡ أضف للمفضلة");
        favorite.setTextSize(14);
        favorite.setOnClickListener(view -> {
            toggleFavorite(current[0]);
            favorite.setText(favorites.containsKey(tile.key()) ? "♥ في المفضلة" : "♡ أضف للمفضلة");
        });
        buttons.addView(favorite, new LinearLayout.LayoutParams(0, -2, 1));
        Button trailer = action("YouTube");
        trailer.setTextSize(14);
        trailer.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.youtube_mark, 0, 0, 0);
        trailer.setCompoundDrawablePadding(dp(5));
        trailer.setContentDescription("إعلان الفيلم على YouTube");
        trailer.setOnClickListener(view -> openTrailer(current[0].entry));
        
        buttons.addView(trailer, new LinearLayout.LayoutParams(0, -2, 1));
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(Math.min(getResources().getDisplayMetrics().widthPixels - dp(32),
                    dp(920)), Math.min(getResources().getDisplayMetrics().heightPixels - dp(40), dp(420)));
        }
        if (tv) watch.requestFocus();
        if (tile.section != Section.MOVIES) {
            if (tile.entry.plot.isEmpty()) plot.setText("لم يوفر السيرفر وصفًا لهذا العنوان.");
            return;
        }
        XtreamClient active = client;
        fetch(() -> active.movieInfo(tile.entry.id), result -> {
            if (!dialog.isShowing()) return;
            JSONObject info = result.optJSONObject("info");
            if (info == null) info = new JSONObject();
            JSONObject movieData = result.optJSONObject("movie_data");
            info = mergeMetadata(tile.entry.metadata, info);
            if (imdbUrl(info).isEmpty() && movieData != null) {
                info = mergeMetadata(info, movieData);
            }
            String story = cleanString(info, "plot");
            plot.setText(story.isEmpty() ? "لم يوفر السيرفر وصفًا لهذا العنوان." : story);
            String art = cleanString(info, "movie_image");
            if (art.isEmpty()) art = tile.entry.art;
            String backdrop = tile.entry.backdrop;
            JSONArray backdrops = info.optJSONArray("backdrop_path");
            if (backdrops != null && !backdrops.optString(0).isEmpty()) backdrop = backdrops.optString(0);
            Entry enriched = new Entry(tile.entry.id, tile.entry.title, tile.entry.extension,
                    art, backdrop, story, tile.entry.added, info);
            current[0] = new Tile(tile.section, enriched, tile.position, tile.duration);
            artwork.show(poster, active.artworkUrl(art), 450);
            String duration = cleanString(info, "duration");
            int seconds = info.optInt("duration_secs", 0);
            if (seconds > 0) duration = formatTime(seconds * 1000);
            metadata.setText((duration.isEmpty() ? "" : duration + "   •   ") + ratingText(info));
            String imdbLink = imdbUrl(info);
            if (!imdbLink.isEmpty()) {
                String page = imdbLink;
                imdb.setOnClickListener(view -> openBrowser(page));
                parents.setOnClickListener(view -> openParentsGuide(page, tile.entry.title));
            }
            String warning = cleanString(info, "content_warnings");
            if (warning.isEmpty()) warning = cleanString(info, "content_advisory");
            String certification = cleanString(info, "age_rating");
            if (certification.isEmpty()) certification = cleanString(info, "mpaa_rating");
            if (!warning.isEmpty()) {
                advisory.setText("تنبيه من السيرفر: " + warning
                        + (certification.isEmpty() ? "" : "\nالتصنيف العمري لدى السيرفر: " + certification));
            } else if (!certification.isEmpty()) {
                advisory.setText("التصنيف العمري لدى السيرفر: " + certification
                        + "\nتفاصيل المشاهد لم تُراجَع بعد. افتح دليل الآباء.");
            }
            String preview = trailerUrl(cleanString(info, "youtube_trailer"));
            if (!preview.isEmpty()) {
                trailer.setVisibility(View.VISIBLE);
                trailer.setOnClickListener(view -> {
                    openWebPage(preview);
                });
            }
        }, error -> {
            if (dialog.isShowing() && tile.entry.plot.isEmpty()) {
                plot.setText("تعذّر تحميل التفاصيل. تقدر تشغّل الفيلم أو تحاول تاني.");
            }
        });
    }

    private static JSONObject mergeMetadata(JSONObject base, JSONObject extra) {
        JSONObject merged = new JSONObject();
        String[] keys = {"category_id", "rating", "rating_5based", "imdb_id", "imdb", "imdb_url", "imdb_rating",
                "youtube_trailer", "duration", "duration_secs", "age_rating", "mpaa_rating", "content_warnings",
                "content_advisory", "plot", "movie_image", "backdrop_path"};
        try {
            for (JSONObject source : new JSONObject[]{base, extra}) {
                for (String key : keys) {
                    Object value = source.opt(key);
                    if (value == null || value == JSONObject.NULL || value.toString().trim().isEmpty()) continue;
                    if ((key.equals("rating") || key.equals("rating_5based") || key.equals("imdb_rating"))
                            && source.optDouble(key, 0) <= 0) continue;
                    merged.put(key, value);
                }
                if ("imdb".equalsIgnoreCase(source.optString("rating_source")) && source.optDouble("rating", 0) > 0) {
                    merged.put("imdb_rating", source.optDouble("rating"));
                }
            }
        } catch (JSONException impossible) {
            throw new AssertionError(impossible);
        }
        return merged;
    }

    private static String ratingText(JSONObject info) {
        double imdb = info.optDouble("imdb_rating", 0);
        if (imdb > 0 && imdb <= 10) return "IMDb ★ " + imdb + "/10";
        double rating = info.optDouble("rating", 0);
        if (rating <= 0 || rating > 10) {
            double five = info.optDouble("rating_5based", 0);
            rating = five > 0 && five <= 5 ? five * 2 : 0;
        }
        return rating > 0 ? "تقييم السيرفر ★ " + rating + "/10" : "التقييم غير متوفر من السيرفر";
    }

    private void openTrailer(Entry entry) {
        String address = trailerUrl(cleanString(entry.metadata, "youtube_trailer"));
        if (!address.isEmpty()) {
            openWebPage(address);
            return;
        }
        new AlertDialog.Builder(this).setTitle("رابط الإعلان غير متوفر من السيرفر")
                .setMessage("تقدر تبحث عن الإعلان الرسمي باسم الفيلم على YouTube.")
                .setPositiveButton("ابحث عن الإعلان", (dialog, which) -> openWebPage(
                        "https://www.youtube.com/results?search_query=" + Uri.encode(entry.title + " official trailer")))
                .setNegativeButton("رجوع", null).show();
    }

    private void openParentsGuide(String titlePage, String title) {
        if (!titlePage.isEmpty()) {
            openBrowser(titlePage.replaceAll("/+$", "") + "/parentalguide/");
            return;
        }
        new AlertDialog.Builder(this).setTitle("معرّف IMDb غير متوفر للفيلم")
                .setMessage("افتح نتيجة الفيلم الصحيحة في البحث، ثم اختار All topics وبعدها Parents Guide لمراجعة نوع المشاهد.")
                .setPositiveButton("ابحث عن الفيلم", (dialog, which) -> openBrowser("https://www.imdb.com/find/?q=" + Uri.encode(title)))
                .setNegativeButton("رجوع", null).show();
    }

    private void openBrowser(String address) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(address));
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        for (String browser : new String[]{"com.android.chrome", "com.sec.android.app.sbrowser", "org.mozilla.firefox", "com.microsoft.emmx"}) {
            try {
                startActivity(new Intent(intent).setPackage(browser));
                return;
            } catch (ActivityNotFoundException unavailable) { }
        }
        try {
            startActivity(Intent.createChooser(intent, "اختار متصفح لفتح دليل الفيلم"));
        } catch (ActivityNotFoundException unavailable) {
            android.widget.Toast.makeText(this, "مفيش متصفح متاح لفتح الرابط.", android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void openWebPage(String address) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(address)));
        } catch (ActivityNotFoundException unavailable) {
            android.widget.Toast.makeText(this, "مفيش تطبيق متاح لفتح الرابط.",
                    android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private static String imdbUrl(JSONObject data) {
        for (String field : new String[]{"imdb_id", "imdb", "imdb_url"}) {
            String value = cleanString(data, field).trim();
            if (value.matches("tt[0-9]{5,12}")) return "https://www.imdb.com/title/" + value + "/";
            try {
                java.net.URI uri = java.net.URI.create(value);
                if (("www.imdb.com".equalsIgnoreCase(uri.getHost()) || "imdb.com".equalsIgnoreCase(uri.getHost()))
                        && uri.getPath() != null && uri.getPath().matches("/title/tt[0-9]{5,12}/?")) {
                    return "https://www.imdb.com" + uri.getPath();
                }
            } catch (IllegalArgumentException ignored) { }
        }
        return "";
    }

    private static String trailerUrl(String value) {
        if (value.matches("[A-Za-z0-9_-]{11}")) return "https://www.youtube.com/watch?v=" + value;
        try {
            java.net.URI uri = java.net.URI.create(value);
            String host = uri.getHost();
            if (("https".equals(uri.getScheme()) || "http".equals(uri.getScheme()))
                    && ("youtube.com".equalsIgnoreCase(host) || "www.youtube.com".equalsIgnoreCase(host)
                    || "m.youtube.com".equalsIgnoreCase(host) || "youtu.be".equalsIgnoreCase(host))) return value;
        } catch (IllegalArgumentException ignored) { }
        return "";
    }

    private TextView sectionHeading(String title) {
        TextView heading = label(title, 19, TEXT);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.RIGHT);
        return heading;
    }

    private void addShelf(LinearLayout feed, String title, List<Tile> tiles, boolean resume) {
        feed.addView(sectionHeading(title), marginBelow(6));
        if (tiles.isEmpty()) {
            TextView empty = label(resume ? "الأفلام والحلقات اللي بدأت تتفرج عليها هتظهر هنا." : "مفيش عناوين متاحة.",
                    14, MUTED);
            empty.setGravity(Gravity.RIGHT);
            feed.addView(empty, marginBelow(12));
            return;
        }
        HorizontalScrollView strip = new HorizontalScrollView(this);
        strip.setHorizontalScrollBarEnabled(false);
        LinearLayout cards = row();
        strip.addView(cards);
        for (Tile tile : tiles.subList(0, Math.min(tiles.size(), 12))) {
            Card card = new Card(true);
            card.bind(tile);
            card.setBackground(inputSurface());
            card.setFocusable(true);
            card.setOnClickListener(view -> activate(tile));
            if (!(resume && tile.section == Section.SERIES)) {
                card.setOnLongClickListener(view -> {
                    toggleFavorite(tile);
                    showHome(catalogMessage);
                    return true;
                });
            }
            LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(dp(wideLayout() ? 196 : 166), -2);
            layout.rightMargin = dp(8);
            cards.addView(card, layout);
        }
        feed.addView(strip, marginBelow(12));
    }

    private void activate(Tile tile) {
        hideKeyboard();
        if (tile.section == Section.SERIES && tile.position == 0 && !viewingEpisodes && (home || category != RESUME)) {
            if (home) {
                section = Section.SERIES;
                category = null;
            }
            openSeries(tile.entry);
        } else {
            if (tile.section == Section.MOVIES) details(tile);
            else openPlayer(tile);
        }
    }

    private static boolean sameCategory(Entry left, Entry right) {
        return left == right || left != null && right != null && left.id != null && left.id.equals(right.id);
    }

    private static List<Entry> categoryEntries(List<Entry> source, String categoryId) {
        List<Entry> selected = new ArrayList<>();
        for (Entry entry : source) {
            String actual = cleanString(entry.metadata, "category_id");
            if (actual.isEmpty() || actual.equals(categoryId)) selected.add(entry);
        }
        return selected;
    }

    private static String searchKey(String value) {
        return java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFKD)
                .replaceAll("[\\p{M}\\u0640]", "").trim().toLowerCase(Locale.ROOT)
                .replaceAll("\\s+", " ");
    }

    private List<Tile> catalogTiles(List<Entry> source) {
        boolean grouped = !viewingEpisodes && section != Section.LIVE && category != FAVORITES && category != RESUME;
        List<Entry> available = grouped ? uniqueCatalogEntries(source) : source;
        List<Entry> ordered = viewingEpisodes ? available : orderedEntries(available, itemOrder);
        List<Tile> result = new ArrayList<>();
        for (Entry entry : ordered) {
            Tile saved = history.get(section.name() + "/" + entry.id);
            if (category == RESUME && !viewingEpisodes) {
                if (saved != null) result.add(saved);
            } else {
                int position = saved == null || section == Section.SERIES && !viewingEpisodes ? 0 : saved.position;
                result.add(new Tile(section, entry, position, position == 0 ? 0 : saved.duration));
            }
        }
        return result;
    }

    private final class CatalogSearch {
        private final EntryAdapter adapter;
        private final List<Tile> local;
        private final TextView heading;
        private final TextView count;
        private final TextView empty;
        private final String normalHeading;
        private final Section activeSection = section;
        private final XtreamClient activeClient = client;
        private final boolean localOnly;
        private Future<?> work;
        private Runnable delayed;
        private int version;

        CatalogSearch(EntryAdapter adapter, List<Tile> local, TextView heading, TextView count, TextView empty, boolean localOnly) {
            this.adapter = adapter;
            this.local = local;
            this.heading = heading;
            this.count = count;
            this.empty = empty;
            this.localOnly = localOnly;
            normalHeading = heading.getText().toString();
        }

        private boolean current() {
            return currentSearch == this && activeSection == section && activeClient == client && !isFinishing();
        }

        void query(boolean immediate) {
            if (!current()) return;
            String term = searchTerm.trim();
            if (term.isEmpty() || localOnly) {
                cancel();
                heading.setText(normalHeading);
                adapter.replace(local, term);
                empty.setText(term.isEmpty() ? "القائمة فاضية." : "مفيش نتائج للاسم ده.");
                count.setText(adapter.getCount() + " عنوان");
                return;
            }
            heading.setText("نتائج البحث في كل " + activeSection.label);
            List<Entry> cached = searchCatalogs.get(activeSection);
            if (cached != null) {
                adapter.replace(catalogTiles(cached), term);
                empty.setText("مفيش نتائج للاسم ده.");
                count.setText(adapter.getCount() + " نتيجة");
                return;
            }
            adapter.replace(local, term);
            empty.setText("جاري البحث في القسم كله…");
            count.setText("جاري البحث…");
            if (work != null && !work.isDone()) return;
            if (delayed != null) searchHandler.removeCallbacks(delayed);
            delayed = this::loadAll;
            if (immediate) delayed.run();
            else searchHandler.postDelayed(delayed, 300);
        }

        private void loadAll() {
            if (!current() || searchTerm.trim().isEmpty()) return;
            final int started = version;
            work = network.submit(() -> {
                try {
                    List<Entry> loaded = entries(activeClient.list(activeSection.itemAction, null),
                            activeSection == Section.SERIES ? "series_id" : "stream_id", "name");
                    runOnUiThread(() -> {
                        if (!current() || started != version || searchTerm.trim().isEmpty()) return;
                        searchCatalogs.put(activeSection, loaded);
                        work = null;
                        query(false);
                    });
                } catch (Exception error) {
                    runOnUiThread(() -> {
                        if (!current() || started != version || searchTerm.trim().isEmpty()) return;
                        work = null;
                        String notice = errorMessage(error) + " اضغط بحث لإعادة المحاولة.";
                        count.setText(notice);
                        empty.setText(notice);
                    });
                }
            });
        }

        void cancel() {
            version++;
            if (delayed != null) searchHandler.removeCallbacks(delayed);
            if (work != null) work.cancel(true);
            work = null;
        }
    }

    private void showCatalog(String message, Runnable retry) {
        catalogMessage = message;
        catalogRetry = retry;
        LinearLayout root = shell();
        LinearLayout body = row();
        body.setGravity(Gravity.TOP);
        addBody(root, body);
        if (wideLayout() && !viewingEpisodes && category != null) {
            ScrollView scroll = new ScrollView(this);
            scroll.setBackground(shape(0xff35528f));
            LinearLayout menu = column();
            menu.setPadding(dp(6), dp(5), dp(6), dp(5));
            scroll.addView(menu);
            for (Entry option : categoryChoices()) {
                Button button = action(option.title);
                button.setTextSize(14);
                button.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                button.setMaxLines(2);
                button.setEllipsize(TextUtils.TruncateAt.END);
                boolean selected = sameCategory(option, category);
                button.setSelected(selected);
                if (selected) {
                    button.setContentDescription("القائمة المختارة، " + option.title);
                    scroll.post(() -> scroll.scrollTo(0, Math.max(0, button.getTop() - dp(8))));
                }
                button.setOnClickListener(view -> loadCategory(option));
                menu.addView(button, marginBelow(4));
            }
            LinearLayout.LayoutParams sidebar = new LinearLayout.LayoutParams(dp(tv ? 205 : 172), -1);
            sidebar.rightMargin = dp(10);
            body.addView(scroll, sidebar);
        }
        LinearLayout content = column();
        body.addView(content, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout tools = row();
        if (viewingEpisodes || !wideLayout()) {
            Button choose = action(viewingEpisodes ? "رجوع" : "التصنيفات");
            choose.setEnabled(viewingEpisodes || category != null);
            choose.setOnClickListener(view -> {
                if (viewingEpisodes) leaveEpisodes();
                else pickCategory();
            });
            tools.addView(choose);
        }
        boolean localSearch = viewingEpisodes || category == FAVORITES || category == RESUME;
        EditText search = field(localSearch ? "ابحث في القائمة…" : "ابحث في كل " + section.label + "…", InputType.TYPE_CLASS_TEXT, true);
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.setText(searchTerm);
        search.setEnabled(category != null || viewingEpisodes);
        tools.addView(search, new LinearLayout.LayoutParams(0, -2, 1));
        Button searchButton = action("بحث");
        searchButton.setTextSize(13);
        searchButton.setPadding(0, dp(5), 0, dp(5));
        searchButton.setEnabled(search.isEnabled());
        tools.addView(searchButton, new LinearLayout.LayoutParams(dp(60), -2));
        if (!viewingEpisodes) {
            Button order = action("ترتيب · " + itemOrder.label);
            order.setTextSize(13);
            order.setMaxLines(1);
            order.setEllipsize(TextUtils.TruncateAt.END);
            order.setContentDescription("ترتيب المحتوى، " + itemOrder.label);
            order.setOnClickListener(view -> chooseOrder(false));
            tools.addView(order, new LinearLayout.LayoutParams(dp(130), -2));
            if (wideLayout() && category != null) {
                Button orderGroups = action("ترتيب التصنيفات");
                orderGroups.setTextSize(12);
                orderGroups.setMaxLines(2);
                orderGroups.setOnClickListener(view -> chooseOrder(true));
                tools.addView(orderGroups, new LinearLayout.LayoutParams(dp(96), -2));
            }
        }
        content.addView(tools, marginBelow(4));

        TextView heading = sectionHeading(viewingEpisodes ? series.title : category == null ? section.label : category.title);
        heading.setMaxLines(1);
        heading.setEllipsize(TextUtils.TruncateAt.END);
        content.addView(heading);
        TextView count = label("", 13, MUTED);
        count.setGravity(Gravity.RIGHT);
        content.addView(count, marginBelow(4));
        if (message != null) {
            TextView notice = label(message, 15, MUTED);
            notice.setGravity(Gravity.CENTER);
            content.addView(notice, marginBelow(6));
        }
        Button retryButton = null;
        if (retry != null) {
            retryButton = action("حاول تاني");
            retryButton.setOnClickListener(view -> retry.run());
            content.addView(retryButton);
        }

        GridView grid = grid(section == Section.LIVE || viewingEpisodes);
        List<Entry> original = viewingEpisodes ? episodes : items;
        List<Tile> tiles = catalogTiles(original);
        EntryAdapter adapter = new EntryAdapter(tiles, section == Section.LIVE || viewingEpisodes);
        adapter.filter(searchTerm);
        count.setText(adapter.getCount() + " عنوان");
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> {
            catalogSelection = position;
            activate(adapter.getItem(position));
        });
        grid.setOnItemLongClickListener((parent, view, position, id) -> {
            if (viewingEpisodes || category == RESUME && section == Section.SERIES) return false;
            toggleFavorite(adapter.getItem(position));
            if (category == FAVORITES) {
                refreshLocalCategory();
                showCatalog(items.isEmpty() ? "القائمة فاضية." : null, null);
            }
            return true;
        });
        FrameLayout results = new FrameLayout(this);
        results.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        TextView empty = label("القائمة فاضية.", 16, TEXT);
        empty.setGravity(Gravity.CENTER);
        results.addView(empty, new FrameLayout.LayoutParams(-1, -1));
        grid.setEmptyView(empty);
        content.addView(results, new LinearLayout.LayoutParams(-1, 0, 1));
        CatalogSearch session = new CatalogSearch(adapter, tiles, heading, count, empty, localSearch);
        if (currentSearch != null) currentSearch.cancel();
        currentSearch = session;
        searchButton.setOnClickListener(view -> {
            session.query(true);
            hideKeyboard();
            grid.requestFocus();
        });
        search.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
                    || actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE
                    || event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_UP) {
                searchButton.performClick();
                return true;
            }
            return false;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int length) {
                searchTerm = s.toString();
                session.query(false);
            }
            @Override public void afterTextChanged(Editable text) { }
        });
        setContentView(root);
        if (!searchTerm.trim().isEmpty()) session.query(false);
        if (tv && retryButton != null) retryButton.requestFocus();
        else if (adapter.getCount() > 0) {
            if (tv) grid.requestFocus();
            grid.setSelection(Math.min(catalogSelection, adapter.getCount() - 1));
        }
    }

    private GridView grid(boolean landscapeCards) {
        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(dp(wideLayout() ? (landscapeCards ? 170 : 124) : (landscapeCards ? 140 : 104)));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(dp(8));
        grid.setVerticalSpacing(dp(9));
        grid.setDrawSelectorOnTop(true);
        GradientDrawable border = shape(Color.TRANSPARENT);
        border.setStroke(dp(2), ACCENT);
        grid.setSelector(border);
        grid.setClipToPadding(false);
        return grid;
    }

    private List<Entry> categoryChoices() {
        List<Entry> choices = new ArrayList<>();
        choices.add(ALL);
        choices.add(FAVORITES);
        choices.add(RECENT);
        if (section != Section.LIVE) choices.add(RESUME);
        choices.addAll(orderedEntries(categories, categoryOrder));
        return choices;
    }

    private void pickCategory() {
        List<Entry> choices = categoryChoices();
        String[] names = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) names[i] = choices.get(i).title;
        new AlertDialog.Builder(this).setTitle("التصنيفات")
                .setSingleChoiceItems(names, choices.indexOf(category), (dialog, index) -> {
                    dialog.dismiss();
                    loadCategory(choices.get(index));
                }).setNegativeButton("إلغاء", null).show();
    }

    private void refreshLocalCategory() {
        if (category != FAVORITES && category != RESUME) return;
        List<Entry> local = new ArrayList<>();
        Map<String, Tile> source = category == FAVORITES ? favorites : history;
        for (Tile tile : source.values()) {
            if (tile.section == section) local.add(tile.entry);
        }
        if (category == RESUME) Collections.reverse(local);
        items = local;
    }

    private void leaveEpisodes() {
        cancelRequest();
        viewingEpisodes = false;
        series = null;
        episodes = Collections.emptyList();
        searchTerm = "";
        if (home) showHome(null);
        else showCatalog(items.isEmpty() ? "القائمة فاضية." : null, null);
    }

    private void toggleFavorite(Tile tile) {
        if (favorites.remove(tile.key()) == null) {
            favorites.put(tile.key(), new Tile(tile.section, tile.entry, 0, 0));
            if (favorites.size() > 100) favorites.remove(favorites.keySet().iterator().next());
            android.widget.Toast.makeText(this, "اتضاف للمفضلة", android.widget.Toast.LENGTH_SHORT).show();
        } else {
            android.widget.Toast.makeText(this, "اتشال من المفضلة", android.widget.Toast.LENGTH_SHORT).show();
        }
        saveTiles("favorites", favorites);
    }

    private void restoreTiles(String name, Map<String, Tile> target) {
        target.clear();
        try {
            JSONArray list = new JSONArray(watchData.getString(accountKey + "/" + name, "[]"));
            for (int i = 0; i < list.length(); i++) {
                JSONObject data = list.getJSONObject(i);
                Entry entry = new Entry(data.getString("id"), data.getString("title"), data.getString("extension"),
                        data.optString("art"), data.optString("backdrop"), data.optString("plot"), data.optLong("added"),
                        data.optJSONObject("metadata") == null ? new JSONObject() : data.optJSONObject("metadata"));
                Tile tile = new Tile(Section.valueOf(data.getString("section")), entry,
                        data.optInt("position"), data.optInt("duration"));
                target.put(tile.key(), tile);
            }
        } catch (JSONException | IllegalArgumentException ignored) {
            target.clear();
        }
    }

    private void saveTiles(String name, Map<String, Tile> source) {
        JSONArray list = new JSONArray();
        try {
            for (Tile tile : source.values()) {
                Entry entry = tile.entry;
                list.put(new JSONObject().put("section", tile.section.name()).put("id", entry.id)
                        .put("title", entry.title).put("extension", entry.extension).put("art", entry.art)
                        .put("backdrop", entry.backdrop).put("plot", entry.plot).put("added", entry.added).put("metadata", entry.metadata)
                        .put("position", tile.position).put("duration", tile.duration));
            }
        } catch (JSONException impossible) {
            throw new AssertionError(impossible);
        }
        watchData.edit().putString(accountKey + "/" + name, list.toString()).apply();
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this).setMessage("تسجّل خروج من الاشتراك؟")
                .setNegativeButton("إلغاء", null).setPositiveButton("خروج", (dialog, which) -> {
                    cancelRequest();
                    if (!accountStore.rememberActive("")) {
                        android.widget.Toast.makeText(this, "تعذّر حفظ تسجيل الخروج. حاول تاني.",
                                android.widget.Toast.LENGTH_LONG).show();
                        return;
                    }
                    client = null;
                    searchCatalogs.clear();
                    favorites.clear();
                    history.clear();
                    recent = Collections.emptyList();
                    homeLive = Collections.emptyList();
                    home = false;
                    latest = false;
                    accountName = "";
                    viewingEpisodes = false;
                    series = null;
                    episodes = Collections.emptyList();
                    categories = Collections.emptyList();
                    items = Collections.emptyList();
                    showLogin();
                }).show();
    }

    private void openPlayer(Tile tile) {
        if (currentSearch != null) currentSearch.cancel();
        currentSearch = null;
        artwork.pause();
        playingTile = tile;
        playbackLive = tile.section == Section.LIVE;
        playbackUrls = client.streamUrls(tile.section.streamKind, tile.entry.id, tile.entry.extension);
        playbackAttempt = 0;
        previousSystemUi = getWindow().getDecorView().getSystemUiVisibility();
        previousOrientation = getRequestedOrientation();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams attributes = getWindow().getAttributes();
            previousCutoutMode = attributes.layoutInDisplayCutoutMode;
            attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(attributes);
        }
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setFocusableInTouchMode(true);
        root.setOnClickListener(view -> {
            if (playerTransport.getVisibility() == View.VISIBLE) hidePlayerControls();
            else showPlayerControls();
        });
        playerSurface = root;
        LinearLayout controls = row();
        controls.setPadding(dp(12), dp(6), dp(12), dp(6));
        controls.setBackgroundColor(0xb8142855);
        controls.setClickable(true);
        playerHeader = controls;
        Button back = action("رجوع");
        back.setOnClickListener(view -> closePlayer());
        controls.addView(back);
        TextView title = label(tile.entry.title, 18, TEXT);
        title.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        title.setMaxLines(2);
        controls.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        CasperPlayer video = new CasperPlayer(this);
        video.setFocusable(false);
        player = video;
        root.addView(video, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        root.addView(controls, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        playbackStatus = label("", 14, MUTED);
        playbackStatus.setGravity(Gravity.CENTER);
        playbackStatus.setBackgroundColor(0xb8203d78);
        playbackStatus.setPadding(dp(20), dp(12), dp(20), dp(12));
        root.addView(playbackStatus, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        LinearLayout bottom = column();
        bottom.setPadding(dp(12), dp(6), dp(12), dp(6));
        bottom.setBackgroundColor(0xb8142855);
        bottom.setClickable(true);
        playerTransport = bottom;

        timeline = new SeekBar(this);
        timeline.setId(View.generateViewId());
        timeline.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        timeline.setContentDescription("شريط التقديم والترجيع");
        timeline.setMinimumHeight(dp(36));
        timeline.setFocusable(true);
        timeline.setBackground(inputSurface());
        elapsed = label("0:00", 14, TEXT);
        total = label("0:00", 14, TEXT);
        elapsed.setGravity(Gravity.CENTER);
        total.setGravity(Gravity.CENTER);
        LinearLayout timelineControls = row();
        timelineControls.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        timelineControls.addView(elapsed, new LinearLayout.LayoutParams(dp(70), -2));
        timelineControls.addView(timeline, new LinearLayout.LayoutParams(0, -2, 1));
        timelineControls.addView(total, new LinearLayout.LayoutParams(dp(70), -2));
        bottom.addView(timelineControls, marginBelow(3));
        timelineRow = timelineControls;

        timeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar bar) {
                dragging = true;
                playerSurface.removeCallbacks(hideControls);
            }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                dragging = false;
                seekTo(bar.getProgress());
                scheduleControlHide();
            }
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser) {
                    elapsed.setText(formatTime(progress));
                    if (!dragging) seekTo(progress);
                }
            }
        });

        LinearLayout transport = row();
        transport.setGravity(Gravity.CENTER);
        transport.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        Button previous = action("↶ 10");
        previous.setContentDescription("ترجيع عشر ثواني");
        previous.setOnClickListener(view -> seekBy(-10_000));
        Button forward = action("10 ↷");
        forward.setContentDescription("تقديم عشر ثواني");
        forward.setOnClickListener(view -> seekBy(10_000));
        playPause = action("Ⅱ");
        playPause.setContentDescription("تشغيل أو إيقاف مؤقت");
        playPause.setOnClickListener(view -> {
            if (!playbackPrepared) {
                playbackAttempt = 0;
                playUrl(video);
            } else if (video.isPlaying()) {
                video.pause();
                playPause.setText("▶");
            } else {
                if (playbackCompleted && playbackSeekable) seekTo(0);
                video.start();
                playPause.setText("Ⅱ");
            }
            scheduleControlHide();
        });
        if (!playbackLive) transport.addView(previous, new LinearLayout.LayoutParams(dp(76), dp(42)));
        transport.addView(playPause, new LinearLayout.LayoutParams(dp(64), dp(42)));
        if (!playbackLive) transport.addView(forward, new LinearLayout.LayoutParams(dp(76), dp(42)));
        bottom.addView(transport);
        root.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
        hidePlayerControls();
        if (!tv) setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        enterImmersive();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        video.setOnPreparedListener(() -> {
            if (player != video) return;
            playbackPrepared = true;
            playbackStatus.setVisibility(View.GONE);
            playPause.setEnabled(true);
            playPause.setText("Ⅱ");
            boolean seekable = !playbackLive && video.getDuration() > 0
                    && (video.canSeekBackward() || video.canSeekForward());
            playbackSeekable = seekable;
            previous.setEnabled(seekable);
            forward.setEnabled(seekable);
            if (seekable) {
                timeline.setMax(video.getDuration());
                timeline.setKeyProgressIncrement(Math.min(10_000, Math.max(1000, video.getDuration() / 30)));
                timelineRow.setVisibility(View.VISIBLE);
                total.setText(formatTime(video.getDuration()));
                Tile saved = history.get(tile.key());
                if (saved != null && saved.position < video.getDuration()) seekTo(saved.position);
            }
            if (playerTransport.getVisibility() == View.VISIBLE) scheduleControlHide();
            video.post(tick);
        });
        video.setOnErrorListener((what, extra) -> {
            if (player != video) return true;
            playbackPrepared = false;
            video.removeCallbacks(tick);
            timelineRow.setVisibility(View.GONE);
            previous.setEnabled(false);
            forward.setEnabled(false);
            playbackAttempt++;
            if (playbackAttempt < playbackUrls.length) {
                video.post(() -> {
                    if (player == video) playUrl(video);
                });
            } else {
                playbackStatus.setVisibility(View.VISIBLE);
                playbackStatus.setText("التشغيل متعذّر. جرّب تاني أو اختار محتوى تاني.");
                playPause.setEnabled(true);
                playPause.setText("إعادة المحاولة");
                showPlayerControls();
            }
            return true;
        });
        video.setOnInfoListener((what, extra) -> {
            if (player != video) return false;
            if (what == android.media.MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                playbackStatus.setText("جاري تحميل الفيديو…");
                playbackStatus.setVisibility(View.VISIBLE);
                return true;
            }
            if (what == android.media.MediaPlayer.MEDIA_INFO_BUFFERING_END
                    || what == android.media.MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) {
                playbackStatus.setVisibility(View.GONE);
                return true;
            }
            return false;
        });
        video.setOnCompletionListener(() -> {
            if (player != video) return;
            playbackCompleted = true;
            updateTimeline(video.getDuration());
            playPause.setText("▶");
            showPlayerControls();
            if (history.remove(tile.key()) != null) saveTiles("history", history);
        });
        previous.setEnabled(false);
        forward.setEnabled(false);
        playUrl(video);
    }

    private void enterImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void showPlayerControls() {
        if (player == null) return;
        playerHeader.setVisibility(View.VISIBLE);
        playerTransport.setVisibility(View.VISIBLE);
        if (tv) {
            if (playbackSeekable) timeline.requestFocus();
            else playPause.requestFocus();
        }
        scheduleControlHide();
    }

    private void hidePlayerControls() {
        if (player == null) return;
        playerSurface.removeCallbacks(hideControls);
        playerHeader.setVisibility(View.GONE);
        playerTransport.setVisibility(View.GONE);
        playerSurface.requestFocus();
        enterImmersive();
    }

    private void scheduleControlHide() {
        if (player == null) return;
        playerSurface.removeCallbacks(hideControls);
        if (playbackPrepared && !playbackCompleted && !dragging) {
            playerSurface.postDelayed(hideControls, getSharedPreferences("settings", MODE_PRIVATE).getInt("controls_ms", 3500));
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (player != null && playerTransport.getVisibility() == View.VISIBLE) {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) playerSurface.removeCallbacks(hideControls);
            if (event.getActionMasked() == MotionEvent.ACTION_UP
                    || event.getActionMasked() == MotionEvent.ACTION_CANCEL) scheduleControlHide();
        }
        return super.dispatchTouchEvent(event);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (player != null) {
            int code = event.getKeyCode();
            boolean navigation = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN
                    || code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT
                    || code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER;
            if (navigation && event.getAction() == KeyEvent.ACTION_DOWN) {
                if (playerTransport.getVisibility() != View.VISIBLE) {
                    showPlayerControls();
                    return true;
                }
                scheduleControlHide();
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && player != null) enterImmersive();
    }

    private void playUrl(CasperPlayer video) {
        playbackPrepared = false;
        playbackSeekable = false;
        playbackCompleted = false;
        dragging = false;
        timelineRow.setVisibility(View.GONE);
        playbackStatus.setVisibility(View.VISIBLE);
        playbackStatus.setText("جاري تشغيل البث…");
        playPause.setEnabled(false);
        video.setVideoURI(Uri.parse(playbackUrls[playbackAttempt]));
        video.start();
    }

    private void seekBy(int delta) {
        if (player != null) seekTo(player.getCurrentPosition() + delta);
    }

    private void seekTo(int position) {
        if (player == null || !playbackPrepared || !playbackSeekable) return;
        int target = Math.max(0, Math.min(player.getDuration(), position));
        playbackCompleted = false;
        player.seekTo(target);
        updateTimeline(target);
    }

    private void updateTimeline(int position) {
        if (!playbackSeekable) return;
        timeline.setProgress(position);
        elapsed.setText(formatTime(position));
    }

    private static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return seconds >= 3600
                ? String.format(Locale.ROOT, "%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
                : String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
    }

    private void savePlayback() {
        if (player == null || playbackLive || !playbackPrepared || playbackCompleted
                || !playbackSeekable) return;
        int position = player.getCurrentPosition();
        int duration = player.getDuration();
        if (position < 1000 || position >= duration) return;
        Tile saved = new Tile(playingTile.section, playingTile.entry, position, duration);
        history.remove(saved.key());
        history.put(saved.key(), saved);
        if (history.size() > 50) history.remove(history.keySet().iterator().next());
        saveTiles("history", history);
    }

    private void closePlayer() {
        savePlayback();
        stopPlayer();
        if (home && !viewingEpisodes) showHome(null);
        else {
            refreshLocalCategory();
            showCatalog(category == RESUME && items.isEmpty() ? "القائمة فاضية." : null, null);
        }
    }

    private void stopPlayer() {
        if (player == null) return;
        CasperPlayer video = player;
        player = null;
        video.removeCallbacks(tick);
        playerSurface.removeCallbacks(hideControls);
        video.stopPlayback();
        playbackUrls = null;
        playingTile = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(previousSystemUi);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams attributes = getWindow().getAttributes();
            attributes.layoutInDisplayCutoutMode = previousCutoutMode;
            getWindow().setAttributes(attributes);
        }
        if (!tv) setRequestedOrientation(previousOrientation);
        playerSurface = null;
        playerHeader = null;
        playerTransport = null;
        artwork.resume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        savePlayback();
        if (playerSurface != null) playerSurface.removeCallbacks(hideControls);
        if (player != null && player.isPlaying()) {
            player.pause();
            playPause.setText("▶");
        }
    }

    @Override
    public void onBackPressed() {
        if (player != null) {
            if (playerTransport.getVisibility() == View.VISIBLE && playbackPrepared) hidePlayerControls();
            else closePlayer();
        }
        else if (loginVisible && client != null) openHome(false, false);
        else if (viewingEpisodes) leaveEpisodes();
        else if (client != null && (!home || latest)) openHome(false, false);
        else if (client != null) confirmLogout();
        else super.onBackPressed();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (client == null || player != null || loginVisible) return;
        if (home && !viewingEpisodes) showHome(catalogMessage);
        else showCatalog(catalogMessage, catalogRetry);
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent event) {
        if (player != null && playPause.isEnabled() && code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            playPause.performClick();
            return true;
        }
        return super.onKeyDown(code, event);
    }

    @Override
    protected void onDestroy() {
        cancelRequest();
        network.shutdownNow();
        artwork.close();
        stopPlayer();
        super.onDestroy();
    }

    private <T> void fetch(Callable<T> work, Result<T> success, Result<String> failure) {
        cancelRequest();
        int version = requestVersion;
        request = network.submit(() -> {
            try {
                T result = work.call();
                runOnUiThread(() -> {
                    if (version == requestVersion && !isFinishing()) success.accept(result);
                });
            } catch (Exception error) {
                String message = errorMessage(error);
                runOnUiThread(() -> {
                    if (version == requestVersion && !isFinishing()) failure.accept(message);
                });
            }
        });
    }

    private void cancelRequest() {
        requestVersion++;
        if (request != null) request.cancel(true);
        if (currentSearch != null) currentSearch.cancel();
    }

    private String errorMessage(Exception error) {
        if (error instanceof SocketTimeoutException) return "السيرفر اتأخر في الرد. جرّب تاني.";
        if (error instanceof JSONException) return "رد السيرفر مش بصيغة Xtream Codes.";
        if (error.getClass() == IOException.class && error.getMessage() != null) {
            String message = error.getMessage();
            if (message.startsWith("السيرفر") || message.startsWith("رد السيرفر")
                    || message.startsWith("الاشتراك") || message.startsWith("القائمة") || message.startsWith("حفظ")) return message;
        }
        return "الاتصال بالسيرفر متعذّر. راجع الإنترنت والرابط والبورت.";
    }

    private static List<Entry> entries(JSONArray data, String idKey, String titleKey) {
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < data.length(); i++) {
            JSONObject item = data.optJSONObject(i);
            if (item == null || item.isNull(idKey)) continue;
            String id = item.optString(idKey);
            String title = item.optString(titleKey);
            if (!id.isEmpty() && !title.isEmpty()) {
                Object backdropValue = item.opt("backdrop_path");
                String backdrop = backdropValue instanceof JSONArray
                        ? ((JSONArray) backdropValue).optString(0, "") : cleanString(item, "backdrop_path");
                String art = cleanString(item, "stream_icon");
                if (art.isEmpty()) art = cleanString(item, "cover");
                entries.add(new Entry(id, title, item.optString("container_extension", "mp4"),
                        art, backdrop, cleanString(item, "plot"),
                        item.optLong("added", item.optLong("last_modified", 0)), mergeMetadata(new JSONObject(), item)));
            }
        }
        return entries;
    }

    private static String cleanString(JSONObject item, String key) {
        return item.isNull(key) ? "" : item.optString(key, "");
    }

    private Order readOrder(String key) {
        String stored = getSharedPreferences("settings", MODE_PRIVATE).getString(key, Order.SERVER.name());
        try {
            return Order.valueOf(stored);
        } catch (IllegalArgumentException invalid) {
            return Order.SERVER;
        }
    }

    private void chooseOrder(boolean forCategories) {
        Order[] choices = forCategories ? new Order[]{Order.SERVER, Order.TITLE_ASC, Order.TITLE_DESC} : Order.values();
        String[] labels = new String[choices.length];
        Order current = forCategories ? categoryOrder : itemOrder;
        int selected = 0;
        for (int i = 0; i < choices.length; i++) {
            labels[i] = choices[i].label;
            if (choices[i] == current) selected = i;
        }
        new AlertDialog.Builder(this).setTitle(forCategories ? "ترتيب التصنيفات" : "ترتيب المحتوى")
                .setSingleChoiceItems(labels, selected, (dialog, index) -> {
                    if (forCategories) categoryOrder = choices[index];
                    else {
                        itemOrder = choices[index];
                        catalogSelection = 0;
                    }
                    String key = (forCategories ? "category_order_" : "item_order_") + section.name();
                    getSharedPreferences("settings", MODE_PRIVATE).edit().putString(key, choices[index].name()).apply();
                    dialog.dismiss();
                    showCatalog(catalogMessage, catalogRetry);
                }).setNegativeButton("رجوع", null).show();
    }

    private static List<Entry> orderedEntries(List<Entry> original, Order order) {
        if (order == Order.SERVER) return original;
        List<Entry> sorted = new ArrayList<>(original);
        if (order == Order.TITLE_ASC || order == Order.TITLE_DESC) {
            java.text.Collator collator = java.text.Collator.getInstance(new Locale("ar"));
            collator.setStrength(java.text.Collator.PRIMARY);
            Collections.sort(sorted, (left, right) -> order == Order.TITLE_ASC
                    ? collator.compare(left.title, right.title) : collator.compare(right.title, left.title));
        } else {
            Collections.sort(sorted, (left, right) -> {
                if (left.added <= 0 || right.added <= 0) {
                    return Boolean.compare(left.added <= 0, right.added <= 0);
                }
                return order == Order.NEWEST ? Long.compare(right.added, left.added) : Long.compare(left.added, right.added);
            });
        }
        return sorted;
    }

    private static List<Entry> getEpisodes(JSONObject data) {
        List<Entry> result = new ArrayList<>();
        Object available = data.opt("episodes");
        if (available instanceof JSONArray) {
            JSONArray array = (JSONArray) available;
            for (int i = 0; i < array.length(); i++) {
                if (array.optJSONArray(i) != null) addEpisodes(result, array.optJSONArray(i), String.valueOf(i + 1));
            }
            if (result.isEmpty()) addEpisodes(result, array, "");
        } else if (available instanceof JSONObject) {
            JSONObject seasons = (JSONObject) available;
            List<String> numbers = new ArrayList<>();
            Iterator<String> keys = seasons.keys();
            while (keys.hasNext()) numbers.add(keys.next());
            Collections.sort(numbers, (a, b) -> {
                try {
                    return Integer.compare(Integer.parseInt(a), Integer.parseInt(b));
                } catch (NumberFormatException ignored) {
                    return a.compareTo(b);
                }
            });
            for (String number : numbers) addEpisodes(result, seasons.optJSONArray(number), number);
        }
        return result;
    }

    private static void addEpisodes(List<Entry> entries, JSONArray data, String season) {
        if (data == null) return;
        for (int i = 0; i < data.length(); i++) {
            JSONObject item = data.optJSONObject(i);
            if (item == null || item.isNull("id")) continue;
            String number = item.optString("episode_num", String.valueOf(i + 1));
            String seasonNumber = item.optString("season", season);
            String title = item.optString("title", "");
            String prefix = (seasonNumber.isEmpty() ? "" : "موسم " + seasonNumber + " · ") + "حلقة " + number;
            JSONObject info = item.optJSONObject("info");
            entries.add(new Entry(item.optString("id"), title.isEmpty() ? prefix : prefix + " · " + title,
                    item.optString("container_extension", "mp4"),
                    info == null ? "" : cleanString(info, "movie_image"), "",
                    info == null ? "" : cleanString(info, "plot"), item.optLong("added", 0)));
        }
    }

    private final class EntryAdapter extends BaseAdapter {
        private List<Tile> original;
        private final boolean landscape;
        private List<Tile> shown;

        EntryAdapter(List<Tile> tiles, boolean landscape) {
            original = tiles;
            shown = tiles;
            this.landscape = landscape;
        }

        @Override public int getCount() { return shown.size(); }
        @Override public Tile getItem(int position) { return shown.get(position); }
        @Override public long getItemId(int position) { return position; }

        void replace(List<Tile> tiles, String query) {
            original = tiles;
            filter(query);
        }

        void filter(String query) {
            String term = searchKey(query);
            if (term.isEmpty()) {
                shown = original;
            } else {
                shown = new ArrayList<>();
                for (Tile tile : original) {
                    if (searchKey(tile.entry.title).contains(term)) shown.add(tile);
                }
            }
            notifyDataSetChanged();
        }

        @Override public View getView(int position, View previous, ViewGroup parent) {
            Card card = previous instanceof Card ? (Card) previous : new Card(landscape);
            card.bind(getItem(position));
            return card;
        }
    }

    private final class Card extends LinearLayout {
        private final ImageView picture;
        private final TextView fallback;
        private final TextView title;
        private final android.widget.ProgressBar progress;
        private final boolean landscape;

        Card(boolean landscape) {
            super(MainActivity.this);
            this.landscape = landscape;
            setOrientation(VERTICAL);
            setBackground(shape(PANEL));
            setClipToOutline(true);

            FrameLayout visual = new FrameLayout(MainActivity.this);
            visual.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{0xff497eb4, 0xff5259a2}));
            int height = landscape ? (wideLayout() ? 104 : 91) : (wideLayout() ? 171 : 158);
            addView(visual, new LinearLayout.LayoutParams(-1, dp(height)));
            fallback = label("", 26, 0xffcfddf8);
            fallback.setGravity(Gravity.CENTER);
            visual.addView(fallback, new FrameLayout.LayoutParams(-1, -1));

            picture = new ImageView(MainActivity.this);
            visual.addView(picture, new FrameLayout.LayoutParams(-1, -1));
            title = label("", wideLayout() ? 15 : 14, TEXT);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setMaxLines(2);
            title.setEllipsize(TextUtils.TruncateAt.END);
            title.setPadding(dp(8), dp(4), dp(8), dp(4));
            addView(title, new LinearLayout.LayoutParams(-1, dp(48)));
            progress = new android.widget.ProgressBar(MainActivity.this, null, android.R.attr.progressBarStyleHorizontal);
            progress.setProgressTintList(ColorStateList.valueOf(ACCENT));
            progress.setMax(1000);
            addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));
        }

        void bind(Tile tile) {
            boolean channel = tile.section == Section.LIVE;
            fallback.setText(channel ? "▣" : tile.section == Section.SERIES ? "▤" : "▶");
            picture.setScaleType(channel ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
            int pad = channel ? dp(12) : 0;
            picture.setPadding(pad, pad, pad, pad);
            String source = landscape && !tile.entry.backdrop.isEmpty() ? tile.entry.backdrop : tile.entry.art;
            artwork.show(picture, client.artworkUrl(source), 260);
            title.setText(tile.entry.title);
            setContentDescription(tile.entry.title);
            progress.setVisibility(tile.duration > 0 ? View.VISIBLE : View.INVISIBLE);
            progress.setProgress(tile.duration > 0 ? (int) (1000L * tile.position / tile.duration) : 0);
        }
    }

    private LinearLayout page() {
        LinearLayout root = column();
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xff167fa0, BACKGROUND, 0xff8850bf}));
        int side = dp(tv ? 25 : 12);
        root.setPadding(side, dp(tv ? 16 : 10), side, dp(8));
        return root;
    }

    private LinearLayout column() {
        LinearLayout result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        return result;
    }

    private LinearLayout row() {
        LinearLayout result = new LinearLayout(this);
        result.setGravity(Gravity.CENTER_VERTICAL);
        return result;
    }

    private LinearLayout.LayoutParams marginBelow(int gap) {
        LinearLayout.LayoutParams result = new LinearLayout.LayoutParams(-1, -2);
        result.bottomMargin = dp(gap);
        return result;
    }

    private TextView label(String text, int size, int color) {
        TextView result = new TextView(this);
        result.setText(text);
        result.setTextColor(color);
        result.setTextSize(size);
        return result;
    }

    private EditText field(String hint, int type, boolean right) {
        EditText input = new EditText(this);
        input.setId(View.generateViewId());
        input.setHint(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setTextSize(16);
        input.setSingleLine();
        input.setInputType(type);
        input.setGravity((right ? Gravity.RIGHT : Gravity.LEFT) | Gravity.CENTER_VERTICAL);
        if (!right) input.setTextDirection(View.TEXT_DIRECTION_LTR);
        input.setPadding(dp(13), dp(5), dp(13), dp(5));
        input.setMinimumHeight(dp(tv ? 38 : 51));
        input.setBackground(inputSurface());
        return input;
    }

    private Button action(String title) {
        Button control = new Button(this);
        control.setId(View.generateViewId());
        control.setText(title);
        control.setAllCaps(false);
        control.setTextSize(15);
        control.setTextColor(new ColorStateList(
                new int[][]{{-android.R.attr.state_enabled}, {android.R.attr.state_focused},
                        {android.R.attr.state_pressed}, {android.R.attr.state_selected}, {}},
                new int[]{0xff8993ad, BACKGROUND, BACKGROUND, ACCENT, TEXT}));
        control.setMinHeight(dp(tv ? 38 : 46));
        control.setMinimumHeight(dp(tv ? 38 : 46));
        control.setPadding(dp(11), dp(5), dp(11), dp(5));
        control.setBackground(surface());
        return control;
    }

    private StateListDrawable surface() {
        StateListDrawable result = new StateListDrawable();
        result.addState(new int[]{android.R.attr.state_focused}, shape(ACCENT));
        result.addState(new int[]{android.R.attr.state_pressed}, shape(ACCENT));
        result.addState(new int[]{android.R.attr.state_selected}, shape(0xff6a57b7));
        GradientDrawable idle = shape(PANEL);
        idle.setStroke(dp(1), 0xff7399ce);
        result.addState(new int[]{}, idle);
        return result;
    }

    private GradientDrawable shape(int color) {
        GradientDrawable result = new GradientDrawable();
        result.setColor(color);
        result.setCornerRadius(dp(8));
        return result;
    }

    private StateListDrawable inputSurface() {
        StateListDrawable result = new StateListDrawable();
        result.addState(new int[]{android.R.attr.state_focused}, outline());
        result.addState(new int[]{}, shape(PANEL));
        return result;
    }

    private GradientDrawable outline() {
        GradientDrawable result = shape(0xff6a57b7);
        result.setStroke(dp(2), ACCENT);
        return result;
    }

    private void hideKeyboard() {
        View focus = getCurrentFocus();
        if (focus != null) {
            InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            keyboard.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
