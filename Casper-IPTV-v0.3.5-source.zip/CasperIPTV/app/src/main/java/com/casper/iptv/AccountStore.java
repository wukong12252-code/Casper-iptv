package com.casper.iptv;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class AccountStore {
    private static final String ALIAS = "casper_accounts_v1";
    private final SharedPreferences preferences;

    AccountStore(Context context) {
        preferences = context.getSharedPreferences("accounts", Context.MODE_PRIVATE);
    }

    String activeKey() {
        return preferences.getString("active_key", null);
    }

    boolean rememberActive(String key) {
        return preferences.edit().putString("active_key", key).commit();
    }

    synchronized JSONArray list() throws Exception {
        String stored = preferences.getString("encrypted", "");
        if (stored.isEmpty()) return new JSONArray();
        JSONObject envelope = new JSONObject(stored);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128,
                Base64.decode(envelope.getString("iv"), Base64.NO_WRAP)));
        byte[] plaintext = cipher.doFinal(Base64.decode(envelope.getString("data"), Base64.NO_WRAP));
        return new JSONArray(new String(plaintext, StandardCharsets.UTF_8));
    }

    synchronized void save(String key, String name, String url, String port, String user, String password) throws Exception {
        JSONArray accounts = list();
        JSONObject account = new JSONObject().put("key", key).put("name", name.isEmpty() ? user : name)
                .put("url", url).put("port", port).put("user", user).put("password", password);
        JSONArray updated = new JSONArray();
        boolean replaced = false;
        for (int i = 0; i < accounts.length(); i++) {
            JSONObject old = accounts.getJSONObject(i);
            if (key.equals(old.getString("key"))) {
                updated.put(account);
                replaced = true;
            } else {
                updated.put(old);
            }
        }
        if (!replaced) updated.put(account);
        write(updated);
    }

    synchronized void remove(String key) throws Exception {
        JSONArray updated = new JSONArray();
        JSONArray accounts = list();
        for (int i = 0; i < accounts.length(); i++) {
            JSONObject account = accounts.getJSONObject(i);
            if (!key.equals(account.getString("key"))) updated.put(account);
        }
        write(updated);
        if (key.equals(activeKey())) rememberActive("");
    }

    private void write(JSONArray accounts) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] ciphertext = cipher.doFinal(accounts.toString().getBytes(StandardCharsets.UTF_8));
        JSONObject envelope = new JSONObject().put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                .put("data", Base64.encodeToString(ciphertext, Base64.NO_WRAP));
        if (!preferences.edit().putString("encrypted", envelope.toString()).commit()) {
            throw new IOException("تعذّر حفظ الحسابات على الجهاز.");
        }
    }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(ALIAS)) return (SecretKey) store.getKey(ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return generator.generateKey();
    }
}
